import pandas as pd
import logging
from stock_price_predictor.schemas.features import FeatureConfig
from stock_price_predictor.features.registry import registry
from stock_price_predictor.utils.config_loader import load_config

logger = logging.getLogger(__name__)

class FeaturePipeline:
    """
    Main Feature Engineering Pipeline.

    This class handles feature transformation based on a configuration file, 
    applies registered feature functions from the registry, and performs final 
    curation including feature selection and target creation for forecasting.

    Attributes
    ----------
    config: FeatureConfig
        Configuration object containing feature definitions, selections, and 
        target specification.
    """

    def __init__(self, config_path: str = "feature_config"):
        """
        Initialize FeaturePipeline with a configuration file.

        Parameters
        ----------
        config_path : str, optional
            Path to the feature configuration file or directory. Defaults to 'feature_config'.

        Raises
        ------
        ValueError
            If the configuration contains features that are not registered.
        """
        raw_config = load_config(config_path)
        self.config = FeatureConfig(**raw_config)
        self._validate()
    
    def _validate(self):
        """
        Validate the feature configuration against the feature registry.
        
        Ensures that all feature names in the configuration are present in
        the global feature registry.

        Raises
        ------
        ValueError
            If a feature in the configuration is not defined in the registry.
        """
        for feature_name in self.config.feature_definitions:
            if not registry.get_feature(feature_name):
                raise ValueError(f"Undefined feature: {feature_name}")
        logger.info("Configuration Validated")

    def transform(
            self, 
            df: pd.DataFrame, 
            features_to_apply: list = None, 
            forecast_horizon: int = 1
        ) -> pd.DataFrame:
        """
        Apply selected features to the input DataFrame.

        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame containing raw stock data.
        features_to_apply : list of str, optional
            Specific feature names to apply. If None, all features from the
            configuration will be applied.
        forecast_horizon : int, optional
            Number of periods to shift the target column for forecasting. 
            Defaults to 1.

        Returns
        -------
        pd.DataFrame
            Transformed DataFrame with applied features and curated target column.

        Raises
        ------
        ValueError
            If a feature in `features_to_apply` is not registered.
        Exception
            If any other error occurs during feature transformation.
        """
        try:
            features = [features_to_apply] if isinstance(features_to_apply, str) else features_to_apply

            if features is None:
                features = list(self.config.feature_definitions.keys())

            for feature_name in features:
                if feature_name not in self.config.feature_definitions:
                    raise ValueError(f"Feature {feature_name} is not registered.")
                params = self.config.feature_definitions[feature_name]
                feature_fn = registry.get_feature(feature_name)
                df = feature_fn(df, params)
                
            return self._apply_final_curation(df, forecast_horizon)
        
        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}")
            raise

    def _apply_final_curation(
            self, 
            df: pd.DataFrame, 
            forecast_horizon: int = 1
        ) -> pd.DataFrame:
        """
        Perform final curation on the DataFrame after feature application.

        This includes:
        - Dropping features marked for exclusion.
        - Creating the target column by shifting the 'Close' column backward 
          by forecast horizon.
        - Dropping rows with missing values after transformations.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame after feature transformations.
        forecast_horizon : int, optional
            Number of periods to shift the target column.
            Defaults to 1.

        Returns
        -------
        pd.DataFrame
            Curated DataFrame ready for modeling, with selected features and target.
        """
        df = df.drop(columns=self.config.feature_selection["exclude"])
        df[self.config.feature_selection["target"]] = df["Close"].shift(-forecast_horizon)
        return df.dropna()