"""
Batch Experiments Module.

This module provides a comprehensive framework for conducting large-scale batch
experiments with multiple model configurations, hyperparameter grids, and
validation strategies. It extends the single experiment functionality to enable
systematic exploration of model performance across different parameter spaces.

The module implements parallel execution capabilities, comprehensive result
aggregation, and automated parameter grid generation for efficient hyperparameter
tuning and model comparison workflows. It supports both sequential and parallel
execution modes with configurable worker processes.

Classes
-------
BatchExperiment : class
    Main orchestrator class for conducting batch machine learning experiments
    with parameter grids, parallel execution, and comprehensive results tracking.
"""


import pandas as pd
import numpy as np
import logging
from typing  import Dict, List, Optional, Union, Callable, Any, Tuple, Type
from datetime import datetime
from itertools import product
import copy
import time
from concurrent.futures import ProcessPoolExecutor, as_completed

from stock_price_predictor.utils.config_loader import load_config, export_config, get_config_path
from stock_price_predictor.utils.hash_utils import make_hashable
from stock_price_predictor.experiments.single_experiment import Experiment

logger = logging.getLogger(__name__)

class BatchExperiment(Experiment):
    """
    Orchestrator for conducting large-scale batch machine learning experiments.

    This class extends the single experiment functionality to enable systematic
    exploration of model performance across parameter grids, multiple model types,
    and different validation strategies. It provides parallel execution capabilitities
    and comprehensive result aggregation for efficient hyperparameter tuning and 
    model comparion workflows.

    The class inherits from Experiment to maintain compatibility with single
    experiment configurations while adding batch-specific functionality for
    parameter grid generation, parallel execution management, and result
    consolidation across multiple experiment variations.

    Extends
    -------
    Experiment
        Inherits base experiment configuration, execution, and tracking.

    Parameters
    ----------
    experiment_config_path : str, default="experiment_config"
        Path to the base experiment configuration file that will be varied
        across the batch.
    feature_config_path : str, default="feature_config"
        Path to the feature engineering configuration file.
    mlflow_config_path : str, default="mlflow_config"
        Path to the MLflow configuration file for experiment tracking.
    experiment_name : str, optional
        Custom name for the MLflow experiment. If None, uses name from config.
    run_id : str, optional
        Specific MLflow run ID to resume. If None, creates new runs.
    parallelism : int, default=1
        Number of parallel worker processes for experiment execution.
        Must be >= 1.
    batch_output_dir : str, default="batch_results"
        Directory for storing batch experiment outputs and temporary files.

    Attributes
    ----------
    parallelism : int
        Number of processes to run in parallel. Defaults to 1.
    batch_id : str
        Unique identifier for the batch run.
    results : dict
        Dictionary storing results and metadata from the batch execution.
    """

    def __init__(
            self, 
            experiment_config_path: str = "experiment_config", 
            feature_config_path: str = "feature_config", 
            mlflow_config_path: str = "mlflow_config",
            experiment_name: Optional[str] = None, 
            run_id: Optional[str] = None, 
            parallelism: int = 1, 
            batch_output_dir: str = "batch_results"
        ):
        """
        Initialize a BatchExperiment instance.

        Parameters
        ----------
        experiment_config_path : str, optional
            Path to the experiment configuration file. Default is "experiment_config".
        feature_config_path : str, optional
            Path to the feature configuration file. Default is "feature_config".
        mlflow_config_path : str, optional
            Path to the MLflow configuration file. Default is "mlflow_config".
        experiment_name : str, optional
            Name of the experiment. If None, will be derived from config.
        run_id : str, optional
            Identifier for an existing run, if resuming.
        parallelism : int, optional
            Number of experiments to run in parallel. Default is 1 (serial execution).
        batch_output_dir : str, optional
            Directory where batch outputs will be saved. Default is "batch_results".
        """
        super().__init__(experiment_config_path=experiment_config_path, feature_config_path=feature_config_path, mlflow_config_path=mlflow_config_path,
                         experiment_name=experiment_name, run_id=run_id)
        self.parallelism = max(1, parallelism)
        self.batch_id = self._generate_batch_id()
        self.results = {}

    def _generate_batch_id(self) -> str:
        """
        Generate a unique batch ID based on timestamp and experiment config hash.

        Returns
        -------
        str
            A unique batch identifier.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        config_hash = hash(make_hashable(self.experiment_config)) % 10000
        return f"spp_batch_{timestamp}_{config_hash}"
    
    def generate_parameter_grid(self) -> List[Dict]:
        """
        Create a sample parameter grid for batch experiments.

        Returns
        -------
        List[dict]
            A list of parameter configurations including model specifications 
            and validation strategies.
        """
        models = [
            {
                "name": "RandomForest",
                "class": "sklearn.ensemble.RandomForestRegressor",
                "param_grid": [
                    {"n_estimators": 100},
                    {"n_estimators": 200}
                ]
            },
            {
                "name": "XGBoost",
                "class": "xgboost.XGBRegressor",
                "param_grid":[
                    {"n_estimators":100},
                    {"n_estimators":200}
                ]
            }
        ]

        validation_strategies = [
            {
                "strategy": "rolling_window",
                "n_splits": 5,
                "train_size": 14,
                "test_size": 7
            },
            {
                "strategy": "expanding_window",
                "n_splits": 5,
                "train_size": 14,
                "test_size": 7
            }
        ]

        param_grid = []
        for model in models:
            for params, val_strategy in product(model["param_grid"], validation_strategies):
                param_grid.append({
                    "model_name": model["name"],
                    "model_class": model["class"],
                    "model_params": params,
                    "validation": val_strategy
                })
                
        return param_grid
    
    def prepare_experiment_variations(self, parameter_grid: Dict[str, List[Any]], models: Optional[List[Dict[str, Any]]] = None) -> List[Dict]:
        """
        Generate experiment configurations based on parameter grid and models.

        Parameters
        ----------
        parameter_grid : dict
            Dictionary where keys are parameter names (dot notation allowed) and 
            values are lists of possible values.
        models : list of dict, optional
            Model specifications to include in the variations. If provided, each 
            configuration will be replicated with the given models.

        Returns
        -------
        list of dict
            List of experiment configurations, each representing one variation.
        """
        base_config = copy.deepcopy(self.experiment_config)
        experiment_configs = []
        experiment_configs.append(copy.deepcopy(base_config))

        for param_name, param_values in parameter_grid.items():
            if not param_values:
                continue

            new_configs = []
            for config in experiment_configs:
                for value in param_values:
                    new_config = copy.deepcopy(config)
                    parts = param_name.split('.')
                    target = new_config

                    for part in parts[:-1]:
                        if part not in target:
                            target[part] = {}
                        target = target[part]

                    target[parts[-1]] = value
                    new_configs.append(new_config)

            experiment_configs = new_configs

        if models:
            model_configs = []
            for config in experiment_configs:
                for model_spec in models:
                    new_config = copy.deepcopy(config)
                    new_config['model']['name'] = model_spec.get('name')
                    new_config['model']['class'] = model_spec.get('class')
                    new_config['model']['type'] = model_spec.get('type', 'regression')
                    new_config['model']['params'] = model_spec.get('params', {})
                    model_configs.append(new_config)

            experiment_configs = model_configs
        
        for i, config in enumerate(experiment_configs):
            config['variation_id'] = f"{self.batch_id}_var_{i:03d}"

        logger.info(f"Generated {len(experiment_configs)} experiment configurations")
        return experiment_configs   
        
    def _run_single_variation(self, experiment_config: Dict, run_name: Optional[str] = None) -> Dict:
        """
         Run a single experiment variation with the given configuration.

        Parameters
        ----------
        experiment_config : dict
            The configuration for the experiment variation.
        run_name : str, optional
            Name of the run. If None, will be auto-generated.

        Returns
        -------
        dict
            Dictionary containing results, status, execution time, and metadata.

        Raises
        ------
        Exception
            If the experiment execution fails.
        """
        variation_id = experiment_config.get("variation_id", "unknown")
        export_config(config=experiment_config, config_name=f"temp_config_{variation_id}")

        temp_config_path = f"temp_config_{variation_id}"
        experiment_name = self.experiment_name or self.experiment_config.get("experiment_name", "batch_experiment")
        run_name = run_name or f"run_{variation_id}"    
        try:
            experiment = Experiment(
                experiment_config_path=temp_config_path,
                feature_config_path="feature_config",
                experiment_name=experiment_name,
                is_temp_config=True
            ) 
            start_time = time.time()
            results = experiment.run_experiment(run_name=run_name)
            execution_time = time.time() - start_time

            results["execution_time"] = execution_time
            results["variation_id"] = variation_id
            results["experiment_name"] = experiment_name
            results["run_name"] = run_name
            results["status"] = "SUCCESS"

            logger.info(f"Experiment {variation_id} completed in {execution_time:.2f}s")
            return results
        
        except Exception as e:
            logger.error(f"Experiment {variation_id} failed: {str(e)}")
            return {
                'variation_id': variation_id,
                'experiment_name': experiment_name,
                'run_name': run_name,
                'status': 'FAILED',
                'error': str(e)
            }

    def run_batch(self, parameter_grid: Dict[str, List[Any]], models: Optional[List[Dict[str, Any]]] = None,
                  run_name_template: str = "batch_run_{variation_id}") -> Dict:
        """
        Run a batch of experiments with varying parameters.

        Parameters
        ----------
        parameter_grid : dict
            Dictionary specifying the parameter grid for experiments.
        models : list of dict, optional
            List of model configurations to evaluate across the parameter grid.
        run_name_template : str, optional
            Template for naming runs. Default is "batch_run_{variation_id}".

        Returns
        -------
        dict
            Results from the batch run, including summary statistics and 
            experiment-level outcomes.
        """     
        experiment_configs = self.prepare_experiment_variations(parameter_grid, models)

        batch_start_time = time.time()
        total_experiments = len(experiment_configs)

        logger.info(f"Starting batch run with {total_experiments} experiments "
                    f"using parallelism={self.parallelism}")
        
        self.results = {
            "batch_id": self.batch_id,
            "timestamp": datetime.now().isoformat(),
            "total_experiments": total_experiments,
            "successful_experiments": 0,
            "failed_experiments": 0,
            "parameter_grid": parameter_grid,
            "models": models,
            "experiment_results": {}
        }

        if self.parallelism > 1:
            with ProcessPoolExecutor(max_workers=self.parallelism) as executor:
                future_to_config = {
                    executor.submit(
                        self._run_single_variation,
                        config,
                        run_name_template.format(variation_id=config.get('variation_id', 'unknown'))
                    ): config.get('variation_id', 'unknown')
                    for config in experiment_configs                    
                }
                for future in as_completed(future_to_config):
                    variation_id = future_to_config[future]
                    try:
                        result = future.result()
                        self.results['experiment_results'][variation_id] = result
                        if result.get('status') == 'SUCCESS':
                            self.results['successful_experiments'] += 1
                        else:
                            self.results['failed_experiments'] += 1
                    except Exception as e:
                        logger.error(f"Exception processing experiment {variation_id}: {str(e)}")
                        self.results['experiment_results'][variation_id] = {
                            'variation_id': variation_id,
                            'status': 'FAILED',
                            'error': str(e)
                        }
                        self.results['failed_experiments'] += 1
        else:
            for config in experiment_configs:
                variation_id = config.get('variation_id', 'unknown')
                run_name = run_name_template.format(variation_id=variation_id)

                result = self._run_single_variation(config, run_name)
                self.results['experiment_results'][variation_id] = result

                if result.get('status') == 'SUCCESS':
                    self.results['successful_experiments'] += 1
                else:
                    self.results['failed_experiments'] += 1

        batch_execution_time = time.time() - batch_start_time
        self.results['batch_execution_time'] = batch_execution_time

        logger.info(f"Batch execution completed in {batch_execution_time:.2f}s. "
                    f"Successful: {self.results['successful_experiments']}, "
                    f"Failed: {self.results['failed_experiments']}")

        return self.results        