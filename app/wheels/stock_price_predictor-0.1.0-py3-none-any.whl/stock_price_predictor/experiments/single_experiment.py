"""
Single Experiment Module.

This module provides a comprehensive framework for conducting individual machine
learning experiments in stock price prediction. It orchestrates the complete
experiment lifecycle from data loading and feature engineering through model
training, validation, and results logging.

The module implements time-series aware validation strategies including expanding
and rolling window cross-validation, automatic feature pipeline integration,
configurable model training, and comprehensive MLflow experiment tracking.

Classes
-------
Experiment : class
    Main orchestrator class for conducting single ML experimenrs with full
    lifecycle management including data preparation, model training, validation,
    and results tracking.
"""


import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Union, Callable, Any, Tuple, Type
from datetime import datetime
from sklearn.base import BaseEstimator
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

from stock_price_predictor.utils.config_loader import load_config
from stock_price_predictor.utils.hash_utils import make_hashable
from stock_price_predictor.data_processing.feature_engineering import FeaturePipeline
from stock_price_predictor.utils.mlflow_utils import MLflowManager

logger = logging.getLogger(__name__)

class Experiment:
    """
    A class to manage the lifecycle of a single machine learning experiment.

    This class loads experiment configurations, runs feature engineering,
    creates models dynamically, performs time-series validation splits,
    logs results to MLflow, and returns experiment outcomes.

    Parameters
    ----------
    experiment_config_path : str, optional
        Path to the experiment configuration file. Default is "experiment_config".
    feature_config_path : str, optional
        Path to the feature configuration file. Default is "feature_config".
    mlflow_config_path : str, optional
        Path to the MLflow configuration file. Default is "mlflow_config".
    experiment_name : str, optional
        Name of the experiment for MLflow tracking. If None, defaults to config value.
    run_id : str, optional
        MLflow run ID to resume from. Default is None.
    is_temp_config : bool, optional
        Whether the config file is temporary and should not be cached. Default is False.

    Attributes
    ----------
    experiment_config : dict
        Loaded experiment configuration.
    feature_pipeline : FeaturePipeline
        Pipeline for transforming input features.
    experiment_id : str
        Unique ID generated for this experiment.
    mlflow_manager : MLflowManager
        Manager for MLflow logging and tracking.
    experiment_tags : dict
        Metadata tags for experiment tracking.
    results : dict
        Results of the last executed experiment.
    """

    def __init__(
            self, 
            experiment_config_path: str = "experiment_config", 
            feature_config_path: str = "feature_config", 
            mlflow_config_path: str = "mlflow_config",
            experiment_name: Optional[str] = None, 
            run_id: Optional[str] = None, 
            is_temp_config: bool = False
        ):
        """
        Initialize the Experiment class.

        Parameters
        ----------
        experiment_config_path : str, optional
            Path to the experiment configuration file. Default is "experiment_config".
        feature_config_path : str, optional
            Path to the feature configuration file. Default is "feature_config".
        mlflow_config_path : str, optional
            Path to the MLflow configuration file. Default is "mlflow_config".
        experiment_name : str, optional
            Name of the experiment for MLflow tracking. If None, defaults to config value.
        run_id : str, optional
            MLflow run ID to resume from. Default is None.
        is_temp_config : bool, optional
            Whether to load temporary config files instead of permanent ones. Default is False.

        Raises
        ------
        ValueError
            If required configurations are missing or invalid.
        """
        self.experiment_config = load_config(experiment_config_path, temp_file=is_temp_config)
        self.experiment_id = self._generate_experiment_id()
        self.feature_pipeline = FeaturePipeline(config_path=feature_config_path)
        self.feature_config = load_config("feature_config")
        self.experiment_name = experiment_name
        self.mlflow_manager = MLflowManager(
            config_path=mlflow_config_path,
            tracking_uri="file:///P:/Projects/ML%20Forecasting/python/stock-price-predictor/mlruns",
            experiment_name=experiment_name or self.experiment_config.get("experiment_name")
        )
        self.experiment_tags = {
            "pipeline_version": self.experiment_config.get("version", "0.1.0"),
            "experiment_id": self.experiment_id,
            "timestamp":datetime.now().isoformat()
        }
        self.results = {}
        # self._validate_configs()

        logger.info(f"Initialized Experiment {self.experiment_id}")


    def _generate_experiment_id(self) -> str:
        """
        Generate a unique experiment ID.

        The ID is based on the current timestamp and a hash of the experiment configuration.

        Returns
        -------
        str
            Unique experiment identifier.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        config_hash = hash(make_hashable(self.experiment_config)) % 10000
        return f"spp_exp_{timestamp}_{config_hash}"
    
    def _validate_configs(self):
        """
        Validate consistency across experiment configurations.

        Raises
        ------
        ValueError
            If required experiment keys are missing.
        """
        required_keys = {
            'model', 'data', 'validation',
            'target', 'promotion_thresholds'
        }
        missing = required_keys - self.experiment_tags.keys()
        if missing:
            raise ValueError(f"Missing experiment keys: {missing}")
        
    def _load_data(self) -> pd.DataFrame:
        """
        Load and validate raw dataset.

        Returns
        -------
        pd.DataFrame
            Sorted DataFrame containing stock price data.

        Raises
        ------
        ValueError
            If the data path is not specified or required columns are missing.
        """
        data_path = self.experiment_config['data']['path']
        if data_path is None:
            raise ValueError("Data path not specified")
        df = pd.read_csv(
            data_path, 
            parse_dates=[self.experiment_config['data']['date_col']],
            index_col=self.experiment_config['data']['date_col']
        )

        required_columns = {'Open', 'High', 'Low', 'Close', 'Volume'}
        missing = required_columns - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        
        return df.sort_index()
    
    def _prepare_features(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Apply the feature pipeline to prepare model-ready data.

        Parameters
        ----------
        df : pd.DataFrame
            Raw input dataset.

        Returns
        -------
        X : pd.DataFrame
            Feature matrix after transformations.
        y : pd.Series
            Target variable series.

        Raises
        ------
        KeyError
            If required keys are missing from configuration.
        """
        try:
            forecast_horizon = self.experiment_config['validation'].get('forecast_horizon', 7)
            transformed_df = self.feature_pipeline.transform(df, forecast_horizon=forecast_horizon)
            X = transformed_df.drop(columns=[self.experiment_config['target']])
            y = transformed_df[self.experiment_config['target']]
            return X, y
        except KeyError as e:
            logger.error(f"Feature preparation failed: {str(e)}")
            raise

    def _create_model(self) -> BaseEstimator:
        """
        Create a model instance based on configuration.

        Returns
        -------
        BaseEstimator
            Instantiated scikit-learn compatible model.

        Raises
        ------
        ValueError
            If invalid model parameters are provided.
        """
        model_class = self._import_class(self.experiment_config['model']['class'])
        model_params = self.experiment_config['model']['params']
        try:
            return model_class(**model_params)
        except TypeError as e:
            raise ValueError(f"Invalid model parameters: {str(e)}")
        
    def _import_class(self, class_path: str) -> Type[BaseEstimator]:
        """
        Dynamically import a model class from a module path.

        Parameters
        ----------
        class_path : str
            Full import path to the model class (e.g., 'sklearn.ensemble.RandomForestRegressor').

        Returns
        -------
        Type[BaseEstimator]
            The imported model class.

        Raises
        ------
        ValueError
            If the class cannot be imported.
        """
        module_path, class_name = class_path.rsplit('.', 1)
        try:
            module = __import__(module_path, fromlist=[class_name])
            return getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            raise ValueError(f"Could not import model class {class_path}: {str(e)}")
        
    def _get_validation_splits(self, X: pd.DataFrame) -> list:
        """
        Generate time-series aware validation splits.
        
        Creates train/validation splits appropriate for time series data,
        respecting temporal order to prevent data leakage. Supports both
        expanding window and rolling window strategies.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix.

        Returns
        -------
        list of tuple of slice
            List of train/validation index splits.

        Raises
        ------
        ValueError
            If an unknown validation strategy is specified.
        """
        strategy = self.experiment_config['validation']['strategy']
        if strategy == "expanding_window":
            return self._expanding_window_splits(X)
        elif strategy == "rolling_window":
            return self._rolling_window_splits(X)
        else:
            raise ValueError(f"Unknown validation strategy: {strategy}")
        
    def _expanding_window_splits(self, X: pd.DataFrame) -> list:
        """
        Generate expanding window validation splits.
        
        Creates splits where the training set expands with each fold while
        maintaining a fixed test set size. This strategy is appropriate when
        you want to use all available historical data for training.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix.

        Returns
        -------
        list of tuple of slice
            Train and test index slices for each split.
        """
        n_splits = self.experiment_config['validation']['n_splits']
        test_size = self.experiment_config['validation']['test_size']
        total_size = len(X)
        splits = []
        for i in range(n_splits):
            train_end = test_size * (i + 1)
            test_start = train_end
            test_end = test_start + test_size

            if test_end > total_size:
                break

            splits.append((
                slice(0, train_end),
                slice(test_start, test_end)
            ))
        return splits
    
    def _rolling_window_splits(self, X: pd.DataFrame) -> list:
        """
        Generate rolling window validation splits.
        
        Creates splits with fixed-size training and test windows that slide
        forward through the dataset. This strategy simulates a production
        environment where you retrain with a fixed amount of recent data.

        Parameters
        ----------
        X : pd.DataFrame
            Feature matrix.

        Returns
        -------
        list of tuple of slice
            Train and test index slices for each split.
        """
        n_splits = self.experiment_config['validation']['n_splits']
        train_size = self.experiment_config['validation']['train_size']
        test_size = self.experiment_config['validation']['test_size']
        total_size = len(X)

        splits = []
        for i in range(n_splits):
            train_start = i * test_size
            train_end = train_start + train_size
            test_start = train_end
            test_end = test_start + test_size

            if test_end > total_size:
                break

            splits.append((
                slice(train_start, train_end),
                slice(test_start, test_end)
            ))
        return splits
    
    def run_experiment(self, run_name: Optional[str] = None):
        """
        Execute the complete experiment lifecycle.
        
        Orchestrates the full machine learning experiment including data loading,
        feature engineering, model training with cross-validation, final model
        training, evaluation, and comprehensive results logging to MLflow.
        
        This method implements the complete workflow:
        - Load and validate data
        - Apply feature engineering pipeline  
        - Create train/test splits
        - Log experiment metadata and hyperparameters
        - Perform time-series cross-validation
        - Train final model on full training set
        - Evaluate on holdout test set
        - Log model, predictions, and metrics

        Parameters
        ----------
        run_name : str, optional
            Custom run name for MLflow tracking. Default is None.

        Returns
        -------
        dict
            Results dictionary containing predictions, metrics, model info, and dataset info.

        Raises
        ------
        Exception
            If the experiment fails at any stage.
        """
        try:
            run  = self.mlflow_manager.create_run(run_name=run_name)
            if "variation_id" in self.experiment_config:
                self.mlflow_manager.client.set_tag(run.info.run_id, "variation_id", self.experiment_config["variation_id"])
            raw_df = self._load_data()
            X_full, y_full = self._prepare_features(raw_df)
            X_train_val, X_test, y_train_val, y_test = train_test_split(
                X_full, y_full,
                test_size=0.2,
                shuffle=False
            )
            self.mlflow_manager.log_feature_metadata(self.feature_config)
            self.mlflow_manager.log_dataset_metadata(X_train_val)
            model = self._create_model()
            self.mlflow_manager.log_hyperparameters({
                "model_name": self.experiment_config['model']['name'],
                "model_class": self.experiment_config['model']['class'],
                "model_type": self.experiment_config['model']['type'],
                "model_params": self.experiment_config['model']['params'],
                "validation_strategy": self.experiment_config['validation']['strategy'],
                "n_splits": self.experiment_config['validation']['n_splits'],
                "training_window": self.experiment_config['validation']['train_size'],
                "test_window": self.experiment_config['validation']['test_size'],
                "forecast_horizon": self.experiment_config['validation']['forecast_horizon']
            })

            splits = self._get_validation_splits(X_train_val)
            metrics_history = []
            for fold, (train_slice, val_slice) in enumerate(splits):
                X_train, X_val = X_train_val.iloc[train_slice], X_train_val.iloc[val_slice]
                y_train, y_val = y_train_val.iloc[train_slice], y_train_val.iloc[val_slice]

                model.fit(X_train, y_train)
                y_pred = model.predict(X_val)
                metrics = {
                    "mae": mean_absolute_error(y_val, y_pred),
                    "rmse": root_mean_squared_error(y_val, y_pred),
                    "r2": r2_score(y_val, y_pred)
                }
                metrics_history.append(metrics)
                self.mlflow_manager.log_custom_metrics({
                    f'fold_{k}': v for k, v in metrics.items()
                }, step=fold)

            avg_metrics = {
                "mae": np.mean([m["mae"] for m in metrics_history]),
                "rmse": np.mean([m["rmse"] for m in metrics_history]),
                "r2": np.mean([m["r2"] for m in metrics_history])
            }

            model.fit(X_train_val, y_train_val)
            model_uri = self.mlflow_manager.log_model_with_validation(
                model=model,
                artifact_path=self.experiment_config['model']['artifact_path'],
                X_sample=X_train_val.sample(5)
            )
            y_pred_final = model.predict(X_test)
            pred_df = pd.DataFrame({
                "date": y_test.index, 
                "y_true": X_test['Close'],
                "y_test": y_test,
                "y_pred": y_pred_final
            })

            self.mlflow_manager.log_table(
                data=pred_df,
                artifact_file="predictions/predictions.json"
            )
            
            self.results = {
                "run_id": run.info.run_id,
                "predictions": pred_df,
                "metrics": {
                    "average": avg_metrics,
                    "all_folds": metrics_history
                },
                "model_info": {
                    "model_class": self.experiment_config['model']['class'],
                    "params": self.experiment_config['model']['params'],
                    "model_uri": model_uri
                },
                "dataset_info": {
                    "num_samples": X_train_val.shape[0],
                    "num_features": X_train_val.shape[1]
                }
            }
            self.mlflow_manager.end_run(status="FINISHED")
            return self.results

        except Exception as e:
            logger.error(f"Experiment failed: {str(e)}")
            self.mlflow_manager.end_run(status="FAILED")
            raise
