"""
Trading Pipeline Module.

This module defines the high-level orchestration pipeline that connects
machine learning experimentation with trading simulations. It allows users to:

1. Run single ML experiments, generate predictions, and test multiple trading
   strategies on those predictions.
2. Run batch experiments over a parameter grid, track multiple model variations,
   and evaluate trading strategies for each.
3. Log results to MLflow for experiment tracking and reproducibility.
4. Identify the best-performing trading strategy based on performance metrics.

The pipeline integrates the following components:
- Experiment / BatchExperiment: Handles ML model training and prediction.
- TradingSimulator: Simulates trades given predictions and a trading strategy.
- TradingStrategy (Threshold, Momentum, etc.): Defines entry/exit logic.
- MLflow: Stores experiment, model, and simulation metadata.

The pipeline produces structured results, including experiment outputs,
simulation metrics, equity curves, trade logs, and a summary of the best strategy.
"""


import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Union, Any, Tuple
from datetime import datetime
from dataclasses import dataclass, asdict
import json
import os

from stock_price_predictor.utils.config_loader import load_config
from stock_price_predictor.utils.mlflow_utils import MLflowManager
from stock_price_predictor.experiments.single_experiment import Experiment
from stock_price_predictor.experiments.batch_experiments import BatchExperiment
from stock_price_predictor.simulations.simulations import TradingSimulator, ThresholdStrategy, MomentumStrategy, TradingStrategy

logger = logging.getLogger(__name__)

@dataclass
class PipelineResult:
    """
    Encapsulates the complete results of a trading pipeline run.

    Attributes
    ----------
    experiment_id : str
        Unique identifier of the ML experiment or variation ID for batch runs.
    experiment_results : Dict[str, Any]
        Raw outputs from the ML experiment (metrics, predictions, run_id, etc.).
    simulation_results : Dict[str, Dict[str, Any]]
        Results of trading simulations keyed by strategy name. Each entry
        contains strategy configuration, performance metrics, executed trades,
        and equity curve data.
    best_strategy : Optional[str]
        Name of the strategy with the best Sharpe ratio (if simulations were run).
    execution_time : float
        Total pipeline execution time in seconds.
    timestamp : str
        ISO-formatted timestamp of pipeline execution.
    status : str
        Status of the pipeline run. One of {"SUCCESS", "FAILED", "EXPERIMENT_ONLY", "SIMULATION_FAILED"}.
    """
    experiment_id: str
    experiment_results: Dict[str, Any]
    simulation_results: Dict[str, Dict[str, Any]]
    best_strategy: Optional[str]
    execution_time: float
    timestamp: str
    status: str

class TradingPipeline:
    """
    Orchestrates machine learning experiments and trading simulations.

    The TradingPipeline serves as the integration layer between ML experimentation
    and backtesting. It:
    - Runs single or batch ML experiments to generate predictions.
    - Feeds predictions into multiple trading strategies.
    - Executes simulations, collects performance metrics, and logs results to MLflow.
    - Identifies the best-performing strategy based on Sharpe ratio.

    Parameters
    ----------
    experiment_config : str, default="experiment_config"
        Path to the experiment configuration file.
    feature_config : str, default="feature_config"
        Path to the feature configuration file.
    mlflow_config : str, default="mlflow_config"
        Path to the MLflow configuration file.
    simulation_config : str, default="simulation_config"
        Path to the simulation configuration file.
    experiment_name : Optional[str], default=None
        Name of the experiment for MLflow tracking.
    """

    def __init__(
            self, 
            experiment_config: str = "experiment_config", 
            feature_config: str = "feature_config", 
            mlflow_config: str = "mlflow_config", 
            simulation_config: str = "simulation_config", 
            experiment_name: Optional[str] = None
        ):
        """
        Initialize the Trading Pipeline
        """
        self.experiment_config = experiment_config
        self.feature_config = feature_config
        self.mlflow_config = mlflow_config
        self.simulation_config = load_config(simulation_config, temp_file=False)
        self.experiment_name = experiment_name
        self.pipeline_id = self._generate_pipeline_id()
        logger.info(f"Initialized TradingPipeline {self.pipeline_id}")

    def _generate_pipeline_id(self) -> str:
        """
        Generate a unique identifier for the pipeline run.

        Returns
        -------
        str
            A string ID of the form "spp_pip_YYYYMMDD_HHMMSS".
        """
        timestamp = datetime.now().strftime(format="%Y%m%d_%H%M%S")
        return f"spp_pip_{timestamp}"

    def _get_predictions_from_experiment(self, experiment_results: Dict) -> pd.DataFrame:
        """
        Extract predictions from ML experiment results.

        Parameters
        ----------
        experiment_results : Dict
            Output dictionary from an Experiment or BatchExperiment run.

        Returns
        -------
        pd.DataFrame
            DataFrame containing model predictions. Empty if unavailable.
        """
        try:
            if 'predictions' in experiment_results:
                return experiment_results['predictions']
            else:
                logger.warning("`pred_df` not found in experiment results")
                return pd.DataFrame()
        except Exception as e:
            logger.error(f"Failed to extract predictions: {str(e)}")
            return pd.DataFrame
    
    def run_single_pipeline(
            self, 
            strategies: Optional[List[TradingStrategy]] = None,
            simulation_config: Optional[Dict] = None
        ) -> PipelineResult:
        """
        Run a full pipeline for a single ML experiment and multiple trading simulations.

        Workflow:
        1. Train/evaluate ML model using Experiment.
        2. Generate predictions.
        3. Run one or more trading strategies via TradingSimulator.
        4. Select the best-performing strategy.

        Parameters
        ----------
        strategies : Optional[List[TradingStrategy]], default=None
            List of trading strategies to evaluate. If None, defaults to a mix
            of threshold- and momentum-based strategies.
        simulation_config : Optional[Dict], default=None
            Simulation configuration overrides. Falls back to loaded config.

        Returns
        -------
        PipelineResult
            Structured results containing experiment outputs, simulation outcomes,
            and the identified best strategy.

        Raises
        ------
        Exception
            If the experiment or simulations fail, a PipelineResult with
            status "FAILED" is returned.
        """
        start_time = datetime.now()
        
        try:
            logger.info("Starting ML Experiment...")
            experiment = Experiment(
                experiment_config_path=self.experiment_config,
                feature_config_path=self.feature_config,
                mlflow_config_path=self.mlflow_config,
                experiment_name=self.experiment_name
            )
            exp_results = experiment.run_experiment()
            pred_df = self._get_predictions_from_experiment(exp_results)

            if pred_df.empty:
                logger.warning("No predictions available for trading simulations")
                return PipelineResult(
                    experiment_id=experiment.experiment_id,
                    experiment_results=exp_results,
                    simulation_results={},
                    best_strategy=None,
                    execution_time=(datetime.now() - start_time).total_seconds(),
                    timestamp=datetime.now().isoformat(),
                    status="EXPERIMENT_ONLY"
                )
            
            logger.info("Starting trading simulations...")

            sim_config = simulation_config or self.simulation_config["params"]
            simulation_results = self._run_simulations(pred_df, exp_results['run_id'], strategies, sim_config)

            best_strategy = self._find_best_strategy(simulation_results)

            result = PipelineResult(
                experiment_id=experiment.experiment_id,
                experiment_results=exp_results,
                simulation_results=simulation_results,
                best_strategy=best_strategy,
                execution_time=(datetime.now() - start_time).total_seconds(),
                timestamp=datetime.now().isoformat(),
                status="SUCCESS"
            )
            
            logger.info(f"Pipeline completed successfully. Best strategy: {best_strategy}")
            return result

        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}")
            return PipelineResult(
                experiment_id=getattr(experiment, 'experiment_id', 'unknown'),
                experiment_results={},
                simulation_results={},
                best_strategy=None,
                execution_time=(datetime.now() - start_time).total_seconds(),
                timestamp=datetime.now().isoformat(),
                status="FAILED"
            )
        
    def run_batch_pipeline(
            self, 
            parameter_grid: Dict[str, List[Any]], 
            models: Optional[List[Dict[str, Any]]] = None,
            strategies: Optional[List[TradingStrategy]] = None, 
            simulation_config: Optional[Dict] = None,
            parallelism: int = 1
        ) -> Dict[str, PipelineResult]:
        """
        Run a batch of experiments and corresponding simulations.

        Workflow:
        1. Generate variations of experiments based on parameter grid.
        2. Train/evaluate models for each variation.
        3. Run trading simulations for each successful experiment.
        4. Aggregate results into PipelineResult objects.

        Parameters
        ----------
        parameter_grid : Dict[str, List[Any]]
            Hyperparameter grid to explore during batch experimentation.
        models : Optional[List[Dict[str, Any]]], default=None
            List of model configurations to evaluate.
        strategies : Optional[List[TradingStrategy]], default=None
            Trading strategies to test per experiment. Defaults to threshold
            and momentum strategies if None.
        simulation_config : Optional[Dict], default=None
            Custom simulation configuration overrides.
        parallelism : int, default=1
            Degree of parallel execution for batch experiments.

        Returns
        -------
        Dict[str, PipelineResult]
            Mapping of variation IDs to PipelineResult objects.
        """
        start_time = datetime.now()
        
        try:
            logger.info("Starting batch experiments...")
            batch_experiment = BatchExperiment(
                experiment_config_path=self.experiment_config,
                feature_config_path=self.feature_config,
                mlflow_config_path=self.mlflow_config,
                experiment_name=self.experiment_name,
                parallelism=parallelism
            )
            batch_results = batch_experiment.run_batch(parameter_grid, models)

            pipeline_results = {}
            successful_experiments = [
                (var_id, result)  for var_id, result in batch_results['experiment_results'].items()
                if result.get('status') == "SUCCESS"
            ]
            logger.info(f"Running Simulations for {len(successful_experiments)} successful experiments...")

            sim_config = simulation_config or self.simulation_config['params']

            for var_id, exp_result in successful_experiments:
                try:
                    pred_df = self._get_predictions_from_experiment(exp_result)

                    if not pred_df.empty:
                        sim_results = self._run_simulations(pred_df, exp_result['run_id'], strategies, sim_config)
                        best_strategy = self._find_best_strategy(sim_results)
                    else:
                        sim_results = {}
                        best_strategy = None

                    pipeline_results[var_id] = PipelineResult(
                        experiment_id=var_id,
                        experiment_results=exp_result,
                        simulation_results=sim_results,
                        best_strategy=best_strategy,
                        execution_time="CALCULATE EXPERIMENT EXECUTION TIME", # exp_result.get('execution_time', 0),
                        timestamp=datetime.now().isoformat(),
                        status="SUCCESS"
                    )

                except Exception as e:
                    logger.error(f"Simulation failed for variation {var_id}: {str(e)}")
                    pipeline_results[var_id] = PipelineResult(
                        experiment_id=var_id,
                        experiment_results=exp_result,
                        simulation_results={},
                        best_strategy=None,
                        execution_time=exp_result.get('batch_execution_time', 0),
                        timestamp=datetime.now().isoformat(),
                        status="SIMULATION_FAILED"
                    )
                
                execution_time = (datetime.now() - start_time).total_seconds()
                logger.info(f"Batch pipeline completed in {execution_time:.2f}s")
        
        except Exception as e:
            logger.error(f"Batch pipeline failed: {str(e)}")
            return {}
        
    def _run_simulations(
            self, 
            pred_df: pd.DataFrame, 
            run_id: str, 
            strategies:Optional[List[TradingStrategy]] = None,
            simulation_config: Optional[Dict] = None,
            mlflow_manager: Optional[MLflowManager] = None
        ) -> Dict[str, Dict[str, Any]]:
        """
        Execute multiple trading simulations on experiment predictions.

        Parameters
        ----------
        pred_df : pd.DataFrame
            Predictions DataFrame from an experiment.
        run_id : str
            MLflow run identifier to log simulation results under.
        strategies : Optional[List[TradingStrategy]], default=None
            Strategies to evaluate. Defaults to threshold and momentum strategies.
        simulation_config : Optional[Dict], default=None
            Simulation configuration overrides.
        mlflow_manager: MLflowManager, Optional
            If provided logs results to MLflow (MLflowManager(config_path="mlflow_config")). If None, no logging.

        Returns
        -------
        Dict[str, Dict[str, Any]]
            Dictionary keyed by strategy name, each containing:
            - strategy_config (name, type, params)
            - performance_metrics (dict of financial metrics)
            - trades (list of executed trades)
            - equity_curve (dict of equity progression over time)
        """
        if strategies is None:
            strategies = [
                ThresholdStrategy(long_threshold=0.02, short_threshold=-0.02, name="threshold_2pct"),
                ThresholdStrategy(long_threshold=0.01, short_threshold=-0.01, name="threshold_1pct"),
                MomentumStrategy(lookback=5, momentum_threshold=0.015, name="momentum_5d"),
                MomentumStrategy(lookback=10, momentum_threshold=0.01, name="momentum_10d")
            ]
        
        sim_config = simulation_config or self.simulation_config['params']
        simulation_results = {}
        for strategy in strategies:
            try:
                simulator = TradingSimulator(**sim_config)
                result = simulator.run_simulation(pred_df, strategy)
                simulation_results[strategy.name] = {
                    "strategy_config": {
                        "name": strategy.name,
                        "type": type(strategy).__name__,
                        "params": getattr(strategy, "__dict__", {})
                    },
                    "perfomance_metrics": result,
                    "trades": [asdict(trade) for trade in simulator.trades],
                    "equity_curve": simulator.equity_curve.to_dict() if simulator.equity_curve is not None else {}
                }
                if mlflow_manager is not None and run_id is not None:
                    simulator.log_to_mlflow(run_id, strategy.name)
                logger.info(f"Simulation completed for strategy: {strategy.name}")
            
            except Exception as e:
                logger.error(F"Simulation failed for strategy {strategy.name}: {str(e)}")
                simulation_results[strategy.name] = {
                    "strategy_config": {"name": strategy.name, "type": type(strategy).__name__},
                    "error": str(e),
                    "status": "FAILED"
                }
        
        return simulation_results
    
    def _find_best_strategy(self, simulation_results: Dict[str, Dict[str, Any]]) -> Optional[str]:
        """
        Select the best strategy based on Sharpe ratio.

        Parameters
        ----------
        simulation_results : Dict[str, Dict[str, Any]]
            Dictionary of simulation results keyed by strategy name.

        Returns
        -------
        Optional[str]
            Name of the best-performing strategy. Returns None if no valid
            performance metrics are found.
        """
        best_strategy = None
        best_sharpe = float('-inf')

        for strategy_name , result in simulation_results.items():
            if "performance_metrics" in result:
                sharpe = result['performance_metrics'].get('sharpe_ratio', float('-inf'))
                if sharpe > best_sharpe:
                    best_sharpe = sharpe
                    best_strategy = strategy_name

        return best_strategy
