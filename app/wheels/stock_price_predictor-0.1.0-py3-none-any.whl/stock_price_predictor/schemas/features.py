from pydantic import BaseModel, Field
from typing import Annotated, List, Optional

class MovingAverageConfig(BaseModel):
    """
    Configuration for calculating Moving Averages (MA) on selected columns.

    Attributes
    ----------
    windows : list[int]
        List of window sizes for which to compute moving averages.
    columns : list[str]
        Dataframe column names to apply to moving averages to. 
    """
    windows: Annotated[List[int], Field(min_items=1)]
    columns: List[str]

class RsiConfig(BaseModel):
    """
    Configuration for Relative Strength Index (RSI) calculation.

    Attributes
    ----------
    window : int
        Window size for computing RSI.
    column : str
        DataFrame column name on which to compute RSI.
    """
    window: Annotated[int, Field(ge=1)]
    column: str

class StochasticOscillatorConfig(BaseModel):
    """
    Configuration for Stochastic Oscillator calculation.

    Attributes
    ----------
    k_window : int
        Window size for %K calculation.
    d_window : int
        Window size for %D calculation.
    high_column : str
        Column name for high prices.
    low_column : str
        Column name for low prices.
    close_column : str
        Column name for closing prices.
    """
    k_window: Annotated[int, Field(ge=1)]
    d_window: Annotated[int, Field(ge=1)]
    high_column: str
    low_column: str
    close_column: str

class BollingerBandsConfig(BaseModel):
    """
    Configuration for Bollinger Bands calculation.

    Attributes
    ----------
    window : int
        Window size for the moving average and band calculation.
    column : str
        Column name on which to compute the bands.
    """
    window: Annotated[int, Field(ge=1)]
    column: str

class AtrConfig(BaseModel):
    """
    Configuration for Average True Range (ATR) calculation.

    Attributes
    ----------
    window : int
        Window size for ATR calculation.
    high_column : str
        Column name for high prices.
    low_column : str
        Column name for low prices.
    close_column : str
        Column name for closing prices.
    """
    window: Annotated[int, Field(ge=1)]
    high_column: str
    low_column: str
    close_column: str

class MacdConfig(BaseModel):
    """
    Configuration for MACD (Moving Average Convergence Divergence) calculation.

    Attributes
    ----------
    fast_period : int
        Window size for the fast EMA.
    slow_period : int
        Window size for the slow EMA.
    signal_period : int
        Window size for the signal line EMA.
    column : str
        Column name to compute MACD on.
    """
    fast_period: Annotated[int, Field(ge=1)]
    slow_period: Annotated[int, Field(ge=1)]
    signal_period: Annotated[int, Field(ge=1)]
    column: str

class ObvConfig(BaseModel):
    """
    Configuration for On-Balance Volume (OBV) calculation.

    Attributes
    ----------
    close_column : str
        Column name for closing prices.
    volume_column : str
        Column name for volume.
    """
    close_column: str
    volume_column: str

class VwapConfig(BaseModel):
    """
    Configuration for Volume Weighted Average Price (VWAP) calculation.

    Attributes
    ----------
    high_column : str
        Column name for high prices.
    low_column : str
        Column name for low prices.
    close_column : str
        Column name for closing prices.
    volume_column : str
        Column name for traded volume.
    """
    high_column: str
    low_column: str
    close_column: str
    volume_column: str

class RocConfig(BaseModel):
    """
    Configuration for Rate of Change (ROC) indicator calculation.

    Attributes
    ----------
    window : int
        Number of periods over which to calculate ROC.
    column : str
        Column name to compute ROC on.
    """
    window: Annotated[int, Field(ge=1)]
    column: str

class CciConfig(BaseModel):
    """
    Configuration for Commodity Channel Index (CCI) calculation.

    Attributes
    ----------
    window : int
        Window size for CCI calculation.
    high_column : str
        Column name for high prices.
    low_column : str
        Column name for low prices.
    close_column : str
        Column name for closing prices.
    """
    window: Annotated[int, Field(ge=1)]
    high_column: str
    low_column: str
    close_column: str

class FeatureConfig(BaseModel):
    """
    Main configuration class for feature engineering.

    Attributes
    ----------
    version : float
        Version number of the configuration.
    feature_definitions : dict
        Dictionary mapping feature names to their configuration objects.
    feature_selection : dict
        Dictionary specifying which features to include or exclude, and the target.
    temporal_features : dict, optional
        Optional dictionary specifying temporal features and their settings.
    """
    version: float
    feature_definitions: dict
    feature_selection: dict
    temporal_features: Optional[dict] = None

    class Config:
        extra = "forbid"

