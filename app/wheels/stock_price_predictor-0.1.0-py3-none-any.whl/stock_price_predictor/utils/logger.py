"""
Logger configuration utility.

This module configures the root logger with a console handler
if none exists. Ensures consistent logging format and log level 
across the project.
"""


import logging

def configure_logger():
    """
    Configure the root logger with console handler if none exists.

    - Sets logging level to INFO.
    - Uses a standard format: timestamp, logger name, level, and message.    
    """
    if not logging.getLogger().hasHandlers():
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[logging.StreamHandler()]
        )

configure_logger()