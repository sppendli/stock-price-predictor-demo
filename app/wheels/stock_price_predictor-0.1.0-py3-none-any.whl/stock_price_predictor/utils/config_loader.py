"""
Utility functions for managing YAML-based configuration files.

This module provides helper functions to:
- Resolve configuration file paths (`get_config_path`)
- Load configuration files into Python dictionaries (`load_config`)
- Export configuration dictionaries to YAML (`export_config`)

Configurations are organized under the `config/` directory at the project root,
with a `temp/` subdirectory for temporary or dynamically generated files.
"""


import yaml
from pathlib import Path
from stock_price_predictor.utils.path_utils import PROJECT_ROOT

def get_config_path(config_name: str, temp_file: bool = False) -> Path:
    """
    Construct the path to a configuration YAML file.

    Parameters
    ----------
    config_name : str
        Name of the configuration file (with or without `.yaml` extension).
    temp_file : bool, optional
        If True, return the path inside the `config/temp` directory.
        Otherwise, return the standard `config` directory path.

    Returns
    -------
    Path
        Path object pointing to the resolved configuration file.
    """
    config_name = config_name.replace(".yaml", "")
    config_path = PROJECT_ROOT / "config" / f"{config_name}.yaml"
    if temp_file:
        config_path = PROJECT_ROOT / "config" / "temp" / f"{config_name}.yaml"
    return config_path

def load_config(config_name: str, temp_file: bool = False) -> dict:
    """
    Load a YAML config file into a Python dictionary.

    Parameters
    ----------
    config_name : str
        Name of the configuration file (without `.yaml` extension).
    temp_file : bool, optional
        If True, load from the `config/temp` directory.
        Otherwise, load from the standard `config` directory.

    Returns
    -------
    dict
        Parsed configuration data.
    """
    config_path = PROJECT_ROOT / "config" / f"{config_name}.yaml"
    if temp_file:
        config_path = PROJECT_ROOT / "config" / "temp" / f"{config_name}.yaml"
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def export_config(config, config_name: str) -> dict:
    """
    Export a configuration dictionary to a YAML file in the `config/temp` directory.

    Parameters
    ----------
    config : dict
        Configuration data to export.
    config_name :str
        Name of the file to export (with or without `.yaml` extension).

    Returns
    -------
    str
        Message confirming the export location and file name.
    """
    config_name = config_name.replace(".yaml", "")
    config_path = PROJECT_ROOT / "config" / "temp" / f"{config_name}.yaml"
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False)
    return f"Exported {config} -> {config_path}"