"""
Utility functions for creating hashable representations of complex objects.

This module provides a helper to convert nested Python data structures 
(e.g., dicts, lists) into immutable and hashable tuples. Useful for caching, 
deduplication, and scenarios requiring deterministic hashing of configs or 
function inputs.
"""


from typing import Any

def make_hashable(obj: Any) -> tuple:
    """
    Recursively convert nested object into a hashable tuples.

    Parameters
    ----------
    obj : Any
        Input object (may be a dict or a list).

    Returns
    -------
    tuple
        A tuple-based representation of the object that can be
        used as a hash key.
    """
    if isinstance(obj, dict):
        return tuple(sorted((k, make_hashable(v)) for k, v in obj.items()))
    if isinstance(obj, list):
        return tuple(make_hashable(x) for x in obj)
    return obj