"""
Path management utilities.

This module centralizes path resolution for project resources
such as the project root and data directories. Ensures consistent
and maintainable path handling across the codebase.
"""


from pathlib import Path

# Corrected PROJECT_ROOT (go up 3 levels from utils/ to reach project root)
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent  # src/stock_price_predictor/utils -> project root

def get_data_path(dir_type: str) -> Path:
    """
    Get the path to a data subdirectory.

    Parameters
    ----------
    dir_type : str
        The type of data directory (e.g., "raw", "processed", "external").

    Returns
    -------
    Path
        Absolute path to the specified data subdirectory.

    Raises
    ------
    FileNotFoundError
        If the requested directory does not exist.
    """
    path = PROJECT_ROOT / "data" / dir_type
    if not path.exists():
        raise FileNotFoundError(f"Directory {path} does not exist. Run fetch_data.py first!")
    return path