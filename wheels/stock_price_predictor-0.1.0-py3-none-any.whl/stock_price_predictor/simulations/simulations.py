"""
Simulations Module.

This module provides a comprehensive framework for backtesting trading strategies
using machine learning predictions. It implements realistic trading simulation
with transaction costs, position sizing algorithms, and comprehensive performance
analytics. The module supports multiple trading strategies and provides detailed
performance metrics for strategy evaluation.

The simulation engine handles complex trading mechanics including position sizing,
transaction costs (commission and slippage), risk management, and realistic
trade execution timing. Performance analysis includes standard financial metrics
such as Sharpe ratio, Sortino ratio, maximum drawdown, and risk-adjusted returns.

Classes
-------
PositionType : Enum
    Enumeration of position types (LONG, SHORT, FLAT).
Trade : dataclass
    Container for individual trade information and metrics.
PerformanceMetrics : dataclass
    Container for comprehensive simulation performance metrics.
TradingStrategy : ABC
    Abstract base class for implementing trading strategies.
ThresholdStrategy : TradingStrategy
    Strategy based on prediction threshold crossings.
MomentumStrategy : TradingStrategy
    Strategy based on prediction momentum signals.
TradingSimulator : class
    Main simulation engine for backtesting trading strategies.
"""


import os
import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Union, Callable, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import matplotlib.pyplot as plt
import tempfile

from stock_price_predictor.utils.mlflow_utils import MLflowManager

logger = logging.getLogger(__name__)

class PositionType(Enum):
    """
    Enumeration of trading position types.

    Attributes
    ----------
    LONG : int
        Long position (value = 1), expecting price to increase.
    SHORT : int
        Short position (value = -1), expecting price to decrease.
    FLAT : int
        No position (value = 0), no market exposure.
    """
    LONG = 1
    SHORT = -1
    FLAT = 0

@dataclass
class Trade:
    """
    Container for individual trade information and performance metrics.
    
    This dataclass captures all relevant information about a completed trade,
    including entry/exit details, financial performance, and duration metrics.
    It provides a standardized format for trade analysis and reporting.
    
    Parameters
    ----------
    entry_date : pd.Timestamp
        Date and time when the position was entered.
    exit_date : pd.Timestamp
        Date and time when the position was exited.
    entry_price : float
        Price at which the position was entered.
    exit_price : float
        Price at which the position was exited.
    quantity : float
        Number of shares or contracts traded.
    position_type : PositionType
        Type of position (LONG, SHORT, or FLAT).
    pnl : float
        Profit and loss in absolute currency terms.
    return_pct : float
        Return as a percentage of invested capital.
    duration_days : int
        Number of days the position was held.
    """
    entry_date: pd.Timestamp
    exit_date: pd.Timestamp
    entry_price: float
    exit_price: float
    quantity: float
    position_type: PositionType
    pnl: float
    return_pct: float
    duration_days: int

@dataclass
class PerformanceMetrics:
    """
    Container for comprehensive trading strategy performance metrics.
    
    This dataclass provides a complete set of financial performance metrics
    commonly used in quantitative finance for strategy evaluation. It includes
    return metrics, risk-adjusted measures, drawdown analysis, and trade statistics.
    
    Parameters
    ----------
    total_return : float
        Total return over the simulation period as a decimal (0.25 = 25%).
    annualized_return : float
        Annualized return adjusted for the simulation period length.
    sharpe_ratio : float
        Risk-adjusted return metric (excess return / volatility).
    sortino_ratio : float
        Downside risk-adjusted return metric (excess return / downside deviation).
    max_drawdown : float
        Maximum peak-to-trough decline as a decimal (negative value).
    calmar_ratio : float
        Annualized return divided by maximum drawdown.
    win_rate : float
        Percentage of profitable trades as a decimal.
    profit_factor : float
        Ratio of gross profit to gross loss.
    recovery_factor : float
        Total return divided by maximum drawdown.
    total_trades : int
        Total number of completed trades.
    winning_trades : int
        Number of profitable trades.
    losing_trades : int
        Number of losing trades.
    avg_trade_duration : float
        Average number of days per trade.
    """
    total_return: float
    annualized_return: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    calmar_ratio: float
    win_rate: float
    profit_factor: float
    recovery_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_trade_duration: float

    def to_dict(self) -> Dict[str, float]:
        """
        Convert performance metrics to dictionary format.
        
        Returns
        -------
        dict
            Dictionary representation of all performance metrics.
        """
        return asdict(self)

class TradingStrategy:
    """
    Abstract base class for implementing trading strategies.
    
    This class provides the interface that all trading strategies must implement
    to be compatible with the TradingSimulator. Concrete strategy classes should
    inherit from this class and implement the generate_signals method.
    
    Parameters
    ----------
    name : str
        Name for the strategy.
    
    Attributes
    ----------
    name : str
        Strategy identifier used for logging and reporting.
    """

    def __init__(self, name: str):
        """
        Initialize a trading strategy.

        Parameters
        ----------
        name : str
            Name of the strategy.
        """
        self.name = name

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        """
        Generate trading signals from prediction data.
        
        This method must be implemented by concrete strategy classes to define
        the signal generation logic. Signals should be numeric values where:
        - Positive values indicate long positions
        - Negative values indicate short positions  
        - Zero indicates no position
        
        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing prediction data and any other required columns.
        
        Returns
        -------
        pd.Series
            Series of trading signals with the same index as input DataFrame.
        
        Raises
        ------
        NotImplementedError
            This method must be implemented by subclasses.
        """
        raise NotImplementedError("Subclasses must implement generate_signals")
    
class ThresholdStrategy(TradingStrategy):
    """
    Trading strategy based on prediction error thresholds.
    
    This strategy generates trading signals by comparing predicted values with
    actual values and triggering trades when the prediction error exceeds
    specified thresholds. It assumes that large prediction errors indicate
    market inefficiencies that can be exploited.
    
    Parameters
    ----------
    long_threshold : float, default=0.01
        Threshold for long signals as a decimal (0.01 = 1%). Triggers long
        position when (y_pred - y_true) / y_true > long_threshold.
    short_threshold : float, default=-0.01
        Threshold for short signals as a decimal. Triggers short position
        when (y_pred - y_true) / y_true < short_threshold.
    name : str, default="threshold"
        Strategy name for identification and logging.
    """

    def __init__(
            self, 
            long_threshold: float = 0.01, 
            short_threshold: float = -0.01, 
            name: str = "threshold"
        ):
        """
        Initialize a ThresholdStrategy.

        Parameters
        ----------
        long_threshold : float, optional
            Threshold for generating long signals. Default is 0.01.
        short_threshold : float, optional
            Threshold for generating short signals. Default is -0.01.
        name : str, optional
            Strategy name. Default is "threshold".
        """
        super().__init__(name)
        self.long_threshold = long_threshold
        self.short_threshold = short_threshold

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        """
        Generate signals based on prediction error thresholds.
        
        Computes the relative prediction error and generates trading signals
        when the error exceeds the configured thresholds. The strategy assumes
        that large prediction errors indicate exploitable market inefficiencies.
        
        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing 'y_pred' and 'y_true' columns for prediction
            and actual values.
        
        Returns
        -------
        pd.Series
            Series of trading signals where:
            - 1: Long signal (prediction error > long_threshold)
            - -1: Short signal (prediction error < short_threshold)
            - 0: No position (error within thresholds)
        
        Raises
        ------
        ValueError
            If the DataFrame does not contain the required 'y_pred' column.
        """
        signals = pd.Series(0, index=df.index)
        if 'y_pred' in df.columns:
            signals[(df['y_pred'] - df['y_true']) / (df['y_true']) > self.long_threshold] = 1
            signals[(df['y_pred'] - df['y_true']) / (df['y_true']) < self.short_threshold] = -1
        else:
            raise ValueError("Dataframe must contain `y_pred` column")
        return signals
    
class MomentumStrategy(TradingStrategy):
    """
    Trading strategy based on prediction momentum.
    
    This strategy generates signals based on the momentum (rate of change) of
    predictions over a specified lookback period. It assumes that trends in
    predictions indicate directional momentum that can be exploited for trading.
    
    Parameters
    ----------
    lookback : int, default=5
        Number of periods to use for momentum calculation.
    momentum_threshold : float, default=0.01
        Minimum momentum magnitude to trigger signals as a decimal (0.01 = 1%).
    name : str, default="momentum"
        Strategy name for identification and logging.
    """

    def __init__(
            self, 
            lookback: int = 5, 
            momentum_threshold: float = 0.01,
            name: str = " momentum"
        ):
        """
        Initialize a MomentumStrategy.

        Parameters
        ----------
        lookback : int, optional
            Lookback window for momentum calculation. Default is 5.
        momentum_threshold : float, optional
            Threshold for signal generation. Default is 0.01.
        name : str, optional
            Strategy name. Default is "momentum".
        """
        super().__init__(name)
        self.lookback = lookback
        self.momentum_threshold = momentum_threshold

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        """
         Generate signals based on prediction momentum.
        
        Calculates the momentum of predictions using a rolling window average
        and percentage change, then generates signals when momentum exceeds
        the specified threshold in either direction.
        
        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing prediction data. Must have either 'prediction'
            or 'y_pred' column.
        
        Returns
        -------
        pd.Series
            Series of trading signals where:
            - 1: Long signal (positive momentum > threshold)
            - -1: Short signal (negative momentum < -threshold)
            - 0: No position (momentum within thresholds)
        """
        signals = pd.Series(0, index=df.index)

        pred_col = "prediction" if "prediction" in df.columns else "y_pred"
        momentum = df[pred_col].rolling(self.lookback).mean().pct_change()

        signals[momentum > self.momentum_threshold] = 1
        signals[momentum < -self.momentum_threshold] = -1
        return signals

class TradingSimulator:
    """
    Comprehensive trading simulation engine for backtesting strategies.
    
    This class provides a realistic trading simulation environment that includes
    transaction costs, position sizing algorithms, risk management, and detailed
    performance tracking. It supports multiple position sizing methods and
    provides comprehensive performance analytics for strategy evaluation.
    
    Parameters
    ----------
    initial_capital : float, default=10000
        Starting capital for the simulation in currency units.
    commission : float, default=0.001
        Commission rate as a decimal (0.001 = 0.1% per trade).
    slippage : float, default=0.0005
        Slippage rate as a decimal (0.0005 = 0.05% per trade).
    position_sizing : str, default="fixed"
        Position sizing algorithm. Options:
        - "fixed": Fixed dollar amount per position
        - "percent_equity": Percentage of current equity
        - "volatility_target": Volatility-adjusted position sizing
    max_position_size : float, default=1.0
        Maximum position size as a fraction of equity or number of shares.
    risk_free_rate : float, default=0.02
        Risk-free rate for Sharpe ratio calculation as a decimal (0.02 = 2%).
    
    Attributes
    ----------
    initial_capital : float
        Starting capital amount.
    commission : float
        Commission rate per trade.
    slippage : float
        Slippage rate per trade.
    position_sizing : str
        Position sizing method identifier.
    max_position_size : float
        Maximum position size constraint.
    risk_free_rate : float
        Risk-free rate for performance calculations.
    equity_curve : pd.DataFrame or None
        Time series of portfolio equity values.
    trades : list
        List of Trade objects representing completed trades.
    performance_metrics : PerformanceMetrics or None
        Calculated performance metrics after simulation.
    mlflow_manager : MLflowManager
        MLflow manager for experiment logging.
    """

    def __init__(
            self, 
            initial_capital: float = 10000, 
            commission: float = 0.001, 
            slippage: float = 0.0005, 
            position_sizing: str = "fixed", 
            max_position_size: float = 1.0, 
            risk_free_rate: float = 0.02,
            mlflow_manager: Optional[MLflowManager] = None
        ):
        """
        Initialize the trading simulator.

        Parameters
        ----------
        initial_capital : float, default=10000
            Starting capital for the simulation in currency units.
        commission : float, default=0.001
            Commission rate as a decimal (0.001 = 0.1% per trade).
        slippage : float, default=0.0005
            Slippage rate as a decimal (0.0005 = 0.05% per trade).
        position_sizing : str, default="fixed"
            Position sizing algorithm. Options:
            - "fixed": Fixed dollar amount per position
            - "percent_equity": Percentage of current equity
            - "volatility_target": Volatility-adjusted position sizing
        max_position_size : float, default=1.0
            Maximum position size as a fraction of equity or number of shares.
        risk_free_rate : float, default=0.02
            Risk-free rate for Sharpe ratio calculation as a decimal (0.02 = 2%).
        mlflow_manager: MLflowManager, Optional
            If provided logs results to MLflow (MLflowManager(config_path="mlflow_config")). If None, no logging.
        """
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        self.position_sizing = position_sizing
        self.max_position_size = max_position_size
        self.risk_free_rate = risk_free_rate
        self.equity_curve = None
        self.trades = []
        self.performance_metrics = None
        self.mlflow_manager = mlflow_manager

    def _calculate_position_size(
            self, 
            signal: float, 
            price: float, 
            equity: float, 
            volatility: float
        ) -> float:
        """
        Calculate position size based on the configured sizing algorithm.
        
        Implements multiple position sizing methods to manage risk and optimize
        capital allocation. The method respects maximum position size constraints
        and adjusts for signal strength and market volatility.
        
        Parameters
        ----------
        signal : float
            Trading signal strength (positive for long, negative for short).
        price : float
            Current asset price for position calculation.
        equity : float
            Current portfolio equity value.
        volatility : float
            Asset volatility estimate for volatility targeting.
        
        Returns
        -------
        float
            Number of shares to trade (positive for long, negative for short).
        """
        if self.position_sizing == "fixed":
            max_shares = (equity * self.max_position_size) / price
            return min (max_shares, abs(signal)) * np.sign(signal)
        elif self.position_sizing =="percent_equity":
            position_value = equity * self.max_position_size * abs(signal)
            return (position_value / price) * np.sign(signal)
        elif self.position_sizing == "volatility_target" and volatility is not None:
            target_vol = 0.15
            vol_adjustment = min(target_vol / max(volatility, 0.01), 1.0)
            position_value = equity * self.max_position_size * vol_adjustment * abs(signal)
            return (position_value / price) * np.sign(signal)
        return (equity * self.max_position_size / price) * np.sign(signal)
    
    def _apply_transaction_costs(self, price: float, quantity: float) -> float:
        """
        Calculate total transaction costs for a trade.
        
        Computes the combined cost of commission and slippage for a trade
        based on the trade value and configured cost rates.
        
        Parameters
        ----------
        price : float
            Asset price at time of trade.
        quantity : float
            Number of shares being traded.
        
        Returns
        -------
        float
            Total transaction cost in currency units.
        """
        trade_value = abs(price * quantity)
        commission_cost = trade_value * self.commission
        slippage_cost = trade_value * self.slippage
        return commission_cost * slippage_cost

    def run_simulation(
            self, 
            preds_df: pd.DataFrame, 
            strategy: TradingStrategy, 
            start_date: Optional[str] = None, 
            end_date: Optional[str] = None, 
            y_true_col: str = "y_true", 
            forecast_horizon: int = 1
        ) -> Dict[str, Any]:
        """
        Execute a complete trading simulation with the specified strategy.
        
        Runs a comprehensive backtest simulation that includes realistic trading
        mechanics, position management, transaction costs, and performance tracking.
        The simulation respects forecast horizons and implements proper trade timing
        to avoid lookahead bias.
        
        Parameters
        ----------
        preds_df : pd.DataFrame
            DataFrame containing predictions and actual values. Must include
            columns: 'date', 'y_pred', 'y_true', 'y_test'.
        strategy : TradingStrategy
            Trading strategy instance that implements signal generation.
        start_date : str, optional
            Start date for simulation in YYYY-MM-DD format. If None, uses
            entire dataset.
        end_date : str, optional
            End date for simulation in YYYY-MM-DD format. If None, uses
            entire dataset.
        y_true_col : str, default="y_true"
            Column name containing actual asset prices.
        forecast_horizon : int, default=1
            Number of periods to hold positions before allowing new trades.
        
        Returns
        -------
        dict
            Dictionary representation of performance metrics including returns,
            risk measures, drawdown statistics, and trade analytics.
        
        Raises
        ------
        ValueError
            If insufficient data is provided for simulation (< 2 rows) or if
            required columns are missing from the DataFrame.
        """
        sim_df = preds_df.copy()
        if start_date:
            sim_df = sim_df[sim_df['date'] >= start_date]
        if end_date:
            sim_df = sim_df[sim_df['date'] <= end_date]

        if len(sim_df) < 2:
            raise ValueError("Insufficient data for simulation")
        
        sim_df['signal'] = strategy.generate_signals(sim_df)
        sim_df['returns'] = sim_df[y_true_col].pct_change()
        sim_df['volatility'] = sim_df['returns'].rolling(window=20).std() * np.sqrt(252)

        cash = self.initial_capital
        current_position = 0
        desired_position = 0
        days_in_position = 0

        equity_history = []
        entry_price = None
        entry_date = None

        for i, (row_num, row) in enumerate(sim_df.iterrows()):
            current_price = row[y_true_col]
            future_price = row['y_test']
            prediction = row['y_pred']
            signal = row['signal']
            date = row['date']
            volatility = row.get('volatility', 0.15)

            equity = cash + (current_position * current_price)

            can_trade = (current_position == 0) or (days_in_position+1 >= forecast_horizon)
            if can_trade:
                if signal != 0:
                    desired_position = self._calculate_position_size(signal, current_price, equity, volatility)
                else:
                    desired_position = 0

            position_change = desired_position - current_position

            if abs(position_change) > 0:
                transaction_costs = self._apply_transaction_costs(current_price, position_change)
                trade_value = position_change * current_price
                cash -= (trade_value + transaction_costs)

                if current_position != 0 and (desired_position == 0 or np.sign(desired_position) != np.sign(current_position)):
                    if entry_price is not None:
                        shares_closed = abs(current_position)
                        pnl = shares_closed * np.sign(current_position) * (current_price - entry_price) - transaction_costs
                        trade = Trade(
                            entry_date=entry_date,
                            exit_date=date,
                            entry_price=entry_price,
                            exit_price=current_price,
                            quantity=abs(current_position),
                            position_type=PositionType.LONG if current_position > 0  else PositionType.SHORT,
                            pnl=pnl,
                            return_pct=pnl / abs(current_position * entry_price) if entry_price != 0 else 0,
                            duration_days=(date - entry_date).days if entry_date else 0
                        )
                        self.trades.append(trade)

                        entry_price = None
                        entry_date = None
                
                current_position = desired_position

                if abs(current_position) > 0 and entry_price is None:
                    entry_price = current_price
                    entry_date = date
                    days_in_position = 0
                elif current_position == 0:
                    entry_price = None
                    entry_date = None
                    days_in_position = 0

            else:
                if current_position != 0:
                    days_in_position += 1

            equity = cash + (current_position * current_price)
            equity_history.append({
                'date': date, 
                'equity': equity,
                'current_price': current_price,
                'prediction': prediction, 
                'future_price': future_price,
                'signal': signal, 
                'cash': cash, 
                'current_position': current_position,
                'volatility': volatility,
                'days_in_position': days_in_position
            })

        self.equity_curve = pd.DataFrame(equity_history).set_index('date')
        self.performance_metrics = self._calculate_performance_metrics(sim_df)
        logger.info("Trading simulation completed successfully")
        return self.performance_metrics.to_dict()
    
    def _calculate_performance_metrics(self, sim_df: pd.DataFrame) -> PerformanceMetrics:
        """
        Calculate comprehensive performance metrics from simulation results.
        
        Computes a full suite of financial performance metrics including return
        measures, risk-adjusted metrics, drawdown analysis, and trade statistics.
        These metrics follow standard financial industry calculations for
        professional strategy evaluation.
        
        Parameters
        ----------
        sim_df : pd.DataFrame
            Simulation DataFrame containing returns and signal data.
        
        Returns
        -------
        PerformanceMetrics
            Complete performance metrics object with all calculated measures.
        """
        returns = sim_df['strategy_returns'] = sim_df['signal'] * sim_df['returns'] - (sim_df['signal'].diff().abs() * (self.commission + self.slippage)).fillna(0)
        equity = self.equity_curve['equity']

        total_return = (equity.iloc[-1] / self.initial_capital) - 1
        annualized_return = (1 + total_return) ** (252 / len(returns)) - 1
        sharpe_ratio = ((annualized_return - self.risk_free_rate) / (returns.std() * np.sqrt(252))) if returns.std() > 0 else 0
        downside_returns = returns[returns < 0]
        sortino_ratio = ((annualized_return - self.risk_free_rate)/ (downside_returns.std() * np.sqrt(252))) if downside_returns.std() > 0 else 0
        max_drawdown = (equity / equity.cummax() - 1).min()
        calmar_ratio = annualized_return / abs(max_drawdown) if max_drawdown != 0 else 0

        if self.trades:
            winning_trades = [t for t in self.trades if t.pnl > 0]
            losing_trades = [t for t in self.trades if t.pnl < 0]
            win_rate = len(winning_trades) / len(self.trades) if self.trades else 0
            gross_profit = sum(t.pnl for t in winning_trades)
            gross_loss = abs(sum(t.pnl for t in losing_trades))
            profit_factor = gross_profit / gross_loss if gross_loss > 0 else np.inf
            recovery_factor = total_return / abs(max_drawdown) if max_drawdown != 0 else 0
            avg_trade_duration = np.mean([t.duration_days for t in self.trades])
        else:
            win_rate = profit_factor = recovery_factor = avg_trade_duration = 0

        return PerformanceMetrics(
            total_return=total_return,
            annualized_return=annualized_return,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            calmar_ratio=calmar_ratio,
            win_rate=win_rate,
            profit_factor=profit_factor,
            recovery_factor=recovery_factor,
            total_trades=len(self.trades),
            winning_trades=len(winning_trades) if self.trades else 0,
            losing_trades=len(losing_trades) if self.trades else 0,
            avg_trade_duration=avg_trade_duration
        )
    
    def plot_results(self, save_path: Optional[str] = None) -> plt.figure:
        """
        Create visualization plots of simulation results.
        
        Generates a comprehensive visualization showing the equity curve and
        drawdown chart for visual analysis of strategy performance. The plot
        provides intuitive insights into strategy behavior and risk characteristics.
        
        Parameters
        ----------
        save_path : str, optional
            File path to save the plot. If None, plot is not saved to disk.
        
        Returns
        -------
        matplotlib.figure.Figure
            Figure object containing the equity curve and drawdown plots.
        
        Raises
        ------
        ValueError
            If simulation has not been run (equity_curve is None).
        """
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
        fig.suptitle("Trading Simulation Results", fontsize=16)

        ax1.plot(self.equity_curve.index, self.equity_curve['equity'], label="Equity Curve")
        ax1.set_ylabel('Equity ($)')
        ax1.grid(True, alpha=0.3)
        ax1.legend()

        drawdown = (self.equity_curve['equity'] / self.equity_curve['equity'].cummax() - 1) * 100
        ax2.fill_between(self.equity_curve.index, drawdown, 0, color='red', alpha=0.3)
        ax2.set_ylabel('Drawdown (%)')
        ax2.set_xlabel('Date')
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300)
        return fig
        
    def log_to_mlflow(
            self, 
            run_id: str, 
            strategy_name: str, 
            artifact_subfolder: str = "trading_simulations"
        ):
        """
        Log comprehensive simulation results to MLflow for tracking and analysis.
        
        Uploads all simulation artifacts including performance metrics, equity
        curve data, individual trade details, visualization plots, and
        configuration parameters to MLflow for comprehensive experiment tracking.
        
        Parameters
        ----------
        run_id : str
            MLflow run ID to log results to.
        strategy_name : str
            Name identifier for the strategy being logged.
        artifact_subfolder : str, default="trading_simulations"
            Subfolder within MLflow artifacts to organize simulation results.
        
        Raises
        ------
        ValueError
            If simulation has not been run (performance_metrics or equity_curve is None).
        Exception
            If MLflow logging operations fail due to connectivity or permission issues.
        """
        if self.performance_metrics is None or self.equity_curve is None:
            raise ValueError("Run simulations using run_simulation() before logging to ML Flow")
        
        try:

            metrics_dict = self.performance_metrics.to_dict()

            with self.mlflow_manager.start_run(run_id=run_id):
                self.mlflow_manager.log_custom_metrics(metrics=metrics_dict)

                equity_df = self.equity_curve.copy()
                equity_df.reset_index(inplace=True)

                artifact_path = f"{artifact_subfolder}/{strategy_name}/equity_curve.json"
                self.mlflow_manager.log_table(
                    data=equity_df,
                    artifact_file=artifact_path
                )

                if self.trades:
                    trades_df = pd.DataFrame([
                        {
                        'entry_date': trade.entry_date,
                        'exit_date': trade.exit_date,
                        'entry_price': trade.entry_price,
                        'exit_price': trade.exit_price,
                        'quantity': trade.quantity,
                        'position_type': trade.position_type.name,
                        'pnl': trade.pnl,
                        'return_pct': trade.return_pct,
                        'duration_days': trade.duration_days
                        }
                        for trade in self.trades
                    ])
                    
                    trades_artifact_path = f"{artifact_subfolder}/{strategy_name}/trades.json"
                    self.mlflow_manager.log_table(
                        data=trades_df,
                        artifact_file=trades_artifact_path
                    )

            fig = self.plot_results()

            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_file:
                plot_path = tmp_file.name
                fig.savefig(plot_path, dpi=300, bbox_inches='tight')
                plt.close(fig)

            try:
                with self.mlflow_manager.start_run(run_id=run_id):
                    self.mlflow_manager.log_artifact(
                        plot_path,
                        artifact_path=f"{artifact_subfolder}/{strategy_name}"
                    )
            finally:
                os.unlink(plot_path)

            simulation_config = {
                "initial_capital": self.initial_capital,
                "commission": self.commission,
                "slippage": self.slippage,
                "position_sizing": self.position_sizing,
                "max_position_size": self.max_position_size,
                "risk_free_rate": self.risk_free_rate
            }

            strategy_params = {
                f"sim_{strategy_name}_{k}": v 
                for k, v in simulation_config.items()
            }

            with self.mlflow_manager.start_run(run_id=run_id):
                for param_name, param_value in strategy_params.items():
                    self.mlflow_manager.client.log_param(run_id, param_name, param_value)

            logger.info(f"Simulation results for strategy `{strategy_name}` logged to MLflow run {run_id} ")

        except Exception as e:
            logger.error(f"Failed to log simulation results to MLflow: {str(e)}")
            raise