"""
Feature Registry Module.

This module provides a centralized registry for managing feature engineering
functions. It allows feature functions to be registered with unique names,
validated with Pydantic, and retrieved for use within the feature pipeline.

Classes
-------
FeatureRegistry : class
    Maintains a global registry of feature functions and provides decorators
    for registering them

Variables
---------
registry: FeatureRegistry
    Singleton instance of the feature registry used across the package
"""


from typing import Callable, Dict
from pydantic import validate_arguments, ConfigDict
import pandas as pd

class FeatureRegistry:
    """
    Registry for feature engineering functions.

    This class maintains a central mapping of feature names to their
    corresponding functions. Each registered function is automatically
    validated with Pydantic, ensuring correct argument types when invoked.

    Attributes
    ----------------
    _registry : dict[str, Callable]
        Internal dictionary mapping feature names to validated functions.

    Methods
    -------
    register(name: str) -> Callable
        Decorator to register a feature funtion under the given name.
    get_feature(name: str) -> Callable | None
        Retrieve aregistered feature function by name.
    """
    _registry: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str):
        """
        Decorator for registering a feature function.
        
        Parameters
        ----------
        name : str
            The feature name to register the function under.

        Returns
        -------
        Callable
            The decorator function that registers the feature.
        """
        def decorator(func: Callable):
            cls._registry[name] = validate_arguments(
                func, 
                config=ConfigDict(
                    arbitrary_types_allowed=True
                )
            )
            return func
        return decorator
    
    @classmethod
    def get_feature(cls, name: str):
        """
        Retrieve a registered feature function by name.

        Parameters
        ----------
        name : str
            The registered feature name.

        Returns
        -------
        Callable | None
            The registered function, or None if not found.
        """
        return cls._registry.get(name)

registry = FeatureRegistry()