"""
Technical indicator feature functions.

This module implements various technical indicators as feature
engineering functions. Each function is registered into the 
`FeatureRegistry` so it can be dynamically applied to a DataFrame
via configuration.

All functions follow the same pattern:
- Accept a pandas DataFrame and a validated config object.
- Compute the indicator(s) defined by the config.
- Append the result(s) as new columns in the DataFrame.
- Return the modified DataFrame.
"""


import pandas as pd
import numpy as np
from .registry import registry
from stock_price_predictor.schemas.features import (
    MovingAverageConfig, RsiConfig, StochasticOscillatorConfig, 
    BollingerBandsConfig, AtrConfig, MacdConfig, ObvConfig, 
    VwapConfig, RocConfig, CciConfig
)

@registry.register("moving_averages")
def add_moving_averages(df: pd.DataFrame, config: MovingAverageConfig) -> pd.DataFrame:
    """
    Add moving average features.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : MovingAverageConfig
        Configuration specifying window sizes and columns for moving averages.

    Returns
    -------
    pd.DataFrame
        DataFrame with additional moving average columns.
    """
    for window in config.windows:
        for col in config.columns:
            df[f"{col}_MA_{window}"] = df[col].rolling(window).mean()
    return df

@registry.register("relative_strength_index")
def add_rsi(df: pd.DataFrame, config: RsiConfig) -> pd.DataFrame:
    """
    Add Relative Strength Index (RSI) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : RsiConfig
        Configuration specifying the window size and input column.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional RSI column.
    """
    delta = df[config.column].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(config.window).mean()
    avg_loss = loss.rolling(config.window).mean()
    rs = avg_gain / avg_loss
    df["RSI"] = 100 - (100 / (1 + rs))
    return df

@registry.register("stochastic_oscillator")
def add_stochastic_oscillator(df: pd.DataFrame, config: StochasticOscillatorConfig) -> pd.DataFrame:
    """
    Add Stochastic Oscillator (%K and %D) features.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : StochasticOscillatorConfig
        Configuration specifying window sizes and column names.

    Returns
    -------
    pd.DataFrame
        DataFrame with additional %K and %D columns.
    """
    low_min = df[config.low_column].rolling(window=config.k_window).mean()
    high_max = df[config.high_column].rolling(window=config.k_window).mean()
    df["%K"] = 100 * ((df[config.close_column] - low_min) / (high_max - low_min))
    df["%D"] = df["%K"].rolling(window=config.d_window).mean()
    return df

@registry.register("bollinger_bands")
def add_bollinger_bands(df: pd.DataFrame, config: BollingerBandsConfig) -> pd.DataFrame:
    """
    Add Bollinger Bands features.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : BollingerBandsConfig
        Configuration specifying the window size and input column.

    Returns
    -------
    pd.DataFrame
        DataFrame with SMA, STD, UPPER_BAND, and LOWER_BAND columns.
    """
    df[f"SMA_{config.window}"] = df[config.column].rolling(window=config.window).mean()
    df[f"STD_{config.window}"] = df[config.column].rolling(window=config.window).std()
    df["UPPER_BAND"] = df[f"SMA_{config.window}"] + (2 * df[f"STD_{config.window}"])
    df["LOWER_BAND"] = df[f"SMA_{config.window}"] - (2 * df[f"STD_{config.window}"])
    return df

@registry.register("average_true_range")
def add_atr(df: pd.DataFrame, config: AtrConfig) -> pd.DataFrame:
    """
    Add Average True Range (ATR) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : AtrConfig
        Configuration specifying window size and input columns.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional ATR column.
    """
    high_low = df[config.high_column] - df[config.low_column]
    high_close = abs(df[config.high_column] - df[config.close_column].shift())
    low_close = abs(df[config.low_column] - df[config.close_column].shift())
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df["ATR"] = tr.rolling(window=config.window).mean()
    return df

@registry.register("moving_average_convergence_divergence")
def add_macd(df: pd.DataFrame, config: MacdConfig) -> pd.DataFrame:
    """
    Add Moving Average Convergence Divergence (MACD) features.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : MacdConfig
        Configuration specifying periods for fast EMA, slow EMA, and signal line.

    Returns
    -------
    pd.DataFrame
        DataFrame with EMA, MACD, SIGNAL, and HISTOGRAM columns.
    """
    df[f"EMA_{config.fast_period}"] = df[config.column].ewm(span=config.fast_period, adjust=False).mean()
    df[f"EMA_{config.slow_period}"] = df[config.column].ewm(span=config.slow_period, adjust=False).mean()
    df["MACD"] = df[f"EMA_{config.fast_period}"] - df[f"EMA_{config.slow_period}"] 
    df["SIGNAL"] = df["MACD"].ewm(span=config.signal_period, adjust=False).mean()
    df["HISTOGRAM"] = df["MACD"] - df["SIGNAL"]
    return df

@registry.register("on_balance_volume")
def add_obv(df: pd.DataFrame, config: ObvConfig) -> pd.DataFrame:
    """
    Add On-Balance Volume (OBV) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price and volume data.
    config : ObvConfig
        Configuration specifying close and volume column names.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional OBV column.
    """
    df["OBV"] = (np.sign(df[config.close_column].diff()) * df[config.volume_column]).fillna(0).cumsum()
    return df

@registry.register("volume_weighted_average_price")
def add_vwap(df: pd.DataFrame, config: VwapConfig) -> pd.DataFrame:
    """
    Add Volume-Weighted Average Price (VWAP) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price and volume data.
    config : VwapConfig
        Configuration specifying high, low, close, and volume columns.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional VWAP column.
    """
    df["VWAP"] = (df[config.volume_column] * (df[config.high_column] + df[config.low_column] + df[config.close_column])/3).cumsum() /  df[config.volume_column].cumsum()
    return df

@registry.register("rate_of_change")
def add_roc(df: pd.DataFrame, config: RocConfig) -> pd.DataFrame:
    """
    Add Rate of Change (ROC) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : RocConfig
        Configuration specifying the input column and window size.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional ROC column.
    """
    df["ROC"] = df[config.column].pct_change(periods=14) * 100
    return df

@registry.register("commodity_channel_index")
def add_cci(df: pd.DataFrame, config: CciConfig):
    """
    Add Commodity Channel Index (CCI) feature.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing stock price data.
    config : CciConfig
        Configuration specifying window size and input columns.

    Returns
    -------
    pd.DataFrame
        DataFrame with an additional CCI column.
    """
    typical_price = (df[config.high_column] + df[config.low_column] + df[config.close_column]) / 3
    sma_tp = typical_price.rolling(window=config.window).mean()
    mean_dev = typical_price.rolling(window=config.window).apply(lambda x: (x - x.mean()).abs().mean())
    df["CCI"] = (typical_price - sma_tp) / (0.015 * mean_dev)
    return df