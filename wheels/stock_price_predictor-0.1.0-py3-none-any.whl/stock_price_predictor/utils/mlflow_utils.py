"""
MLflow utility module.

This module provides the `MLflowManager` class, which standardizes and extends 
MLflow experiment management. It includes functionality for:

- Run lifecycle management (start, end, resume).
- Logging datasets, features, metrics, hyperparameters, and artifacts.
- Model registration, validation, stage transitions, and promotion workflows.
- Production deployment, cleanup, drift detection, and experiment management.

Designed to integrate seamlessly with machine learning pipelines and enforce 
best practices around reproducibility, traceability, and governance.
"""


import os
import pandas as pd
import numpy as np
import mlflow
from mlflow.tracking import MlflowClient
from mlflow.models import infer_signature
from mlflow.exceptions import MlflowException
import logging
from typing import Optional, Dict, Any, Callable, List
from stock_price_predictor.utils.config_loader import load_config
from stock_price_predictor.utils.hash_utils import make_hashable
from sklearn.base import BaseEstimator
import xgboost as xgb
import lightgbm as lgb

logger = logging.getLogger(__name__)

class MLflowManager:
    """
    MLflow experiment manager for tracking machine learning experiments.
    
    This class provides a comprehensive interface for managing MLflow experiments,
    including run management, model logging, registration, and deployment workflows.
    It supports multiple ML frameworks including scikit-learn, XGBoost, and LightGBM.

    Attributes
    ----------
    config : dict
        Loaded configuration dictionary.
    tracking_uri : str
        MLflow tracking URI.
    experiment_name : str
        Name of the current experiment.
    autolog : bool
        Autologging status.
    client : MlflowClient
        MLflow client instance for advanced operations.
    active_run_id : str or None
        ID of the currently active run. 
    """

    def __init__(
            self, 
            config_path: str = "mlflow_config", 
            tracking_uri: Optional[str] = None, 
            experiment_name: Optional[str] = None, 
            autolog: bool = True
        ):
        """
        Initialize MLflowManager with a configuration file.

        Parameters
        ----------
        config_path : str, default="mlflow_config"
            Path to MLflow config YAML (relative to `config/`).
        tracking_uri : str, optional
            Tracking server URI. If None, uses value from config file.
        experiment_name : str, optional
            Name of the MLflow experiment. If None, uses value from config file.
        autolog : bool, default=True
            Whether to enable MLflow autologging.
        """
        self.config = load_config(config_path)
        self.tracking_uri = tracking_uri or self.config["tracking"] ["uri"]
        self.experiment_name = experiment_name or self.config["tracking"]["experiment_name"]
        self.autolog = autolog or self.config["autolog"]["enabled"]
        self._setup_tracking()
        self.client = MlflowClient()
        self.active_run_id = None

    def _setup_tracking(self):
        """
        Config MLflow tracking server and experiment.

        - Sets tracking URI.
        - Creates or selects experiment.
        - Enables autologging if configured.

        Raises
        ------
        Exception
            If tracking URI setup fails, logs error but continues execution.
        """
        try:
            mlflow.set_tracking_uri(self.tracking_uri)
            logger.info(f"MLflow tracking URI: {mlflow.get_tracking_uri()}")
        except Exception as e:
            logger.error(f"Failed to set tracking URI: {e}")

        mlflow.set_experiment(self.experiment_name)

        if self.autolog:
            mlflow.autolog(
                log_input_examples=self.config["autolog"]["log_input_examples"],
                log_model_signatures=self.config["autolog"]["log_model_signatures"],
                log_models = self.config["autolog"]["log_models"]
            )
        
    def create_run(
            self, 
            run_name: Optional[str] = None, 
            tags: Optional[Dict[str, Any]] = None, 
            description: Optional[str] = None
        ):
        """
        Create a new MLflow run with optional metadata.

        Parameters
        ----------
        run_name : str, optional
            Custom run name. Defaults to config value.
        tags : dict, optional
            Run tags for metadata (key-value).
        description : str, optional
            Run description. Defaults to config value.

        Returns
        -------
        mlflow.ActiveRun
            The active MLflow run object.
        """
        active_run = mlflow.start_run(
            run_name=run_name or self.config["tracking"]["run_name"],
            tags=tags or {},
            description=description or self.config["tracking"]["description"]
        )
        self.active_run_id = active_run.info.run_id
        logger.info(f"Started run: {active_run.info.run_id} - {run_name}")
        return active_run
    
    def start_or_resume_run(self, run_id=None):
        """
        Start a new run  or resume an existing one.

        - If an active run exists, resumes it unless a different run_id is provided.
        - If no run is active, starts a new one or resumes the given run_id.

        Parameters
        ----------
        run_id : str, optional
            Run ID to resume. If None, continues the active run.

        Returns
        -------
        mlflow.ActiveRun
            The active MLflow run object.
        """
        active = mlflow.active_run()
        if active:
            if run_id and active.info.run_id != run_id:
                mlflow.end_run()
            elif run_id is None:
                return active

        if run_id:
            client = mlflow.tracking.MlflowClient()
            run_info = client.get_run(run_id)
            mlflow.set_experiment(experiment_id=run_info.info.experiment_id)
        return mlflow.start_run(run_id=run_id)
    
    def start_run(self, run_id=None):
        """
        Alias for `start_or_resume_run`.

        Parameters
        ----------
        run_id : str, optional
            Run ID to resume.

        Returns
        -------
        mlflow.ActiveRun
        """
        return self.start_or_resume_run(run_id=run_id)

    def end_run(self, status:str = "Finished"):
        """
        End the currently active MLflow run.

        Parameters
        ----------
        status : str, default="Finished"
            Final run status. Options: {"Finished", "Failed", "Killed"}.
        """
        mlflow.end_run(status)
        logger.info(f"Ended run {self.active_run_id} with status: {status}")
        self.active_run_id = None
    
    def log_feature_metadata(self, feature_config: dict):
        """
        Log feature engineering configuration and metadata.

        Parameters
        ----------
        feature_config : dict
            Feature configuration containing version, definitions, and selections.

        Raises
        ------
        Exception
            If feature metadata logging fails.
        """
        try:
            hashable_config = make_hashable(feature_config["feature_definitions"])
            mlflow.log_dict(feature_config, "feature_engineering/config.yaml")        
            mlflow.log_params({
                "feature_config_version": feature_config.get("version"),
                "active_features": len(feature_config["feature_definitions"]),
                "feature_set": ",".join(feature_config["feature_definitions"].keys()),
                "feature_config_hash": hash((hashable_config))
            })
            logger.info(f"Logged feature metadata with {len(feature_config["feature_definitions"])} features")
        except Exception as e:
            logger.error(f"Feature metadata logging failed: {str(e)}")

    def log_dataset_metadata(self, df: pd.DataFrame, log_sample: bool = True):
        """
        Log dataset schema, statistics, and optional sample.

        Parameters
        ----------
        df : pandas.DataFrame
            Dataset to log.
        log_sample : bool, default=True
            Whether to log the first 100 rows as a sample.

        Raises
        ------
        Exception
            If dataset logging fails.
        """
        try:
            schema = {
                "columns": list(df.columns),
                "dtypes": df.dtypes.astype(str).to_dict(),
                "shape": df.shape,
                "missing_values": df.isna().sum().to_dict()
            }
            mlflow.log_dict(schema, "data_schema.json")
            if log_sample:
                 mlflow.log_table(df.head(100), "data_sample.json")

        except Exception as e:
            logger.error(f"Dataset logging failed: {str(e)}")
            raise
    
    def log_feature_pipeline(self, feature_config: dict, df: pd.DataFrame):
        """
        Log both feature configuration and dataset schema in one call.

        Parameters
        ----------
        feature_config : dict
            Feature configuration dictionary.
        df : pandas.DataFrame
            Dataset used for feature generation.
        """
        self.log_feature_metadata(feature_config)
        self.log_dataset_metadata(df)
    
    def log_custom_metrics(self, metrics: dict, step: Optional[int] = None):
        """
        Log custom metrics.

        Parameters
        ----------
        metrics : dict
            Dictionary of metric name -> value.
        step : int, optional
            Training step/epoch index.
        """
        mlflow.log_metrics(metrics, step=step)
        logger.info(f"Logged {len(metrics)} custom metrics")
    
    def log_hyperparameters(self, params: dict):
        """
        Log hyperparameters to MLflow.

        Parameters
        ----------
        params : dict
            Dictionary of parameter name -> value.
        """
        mlflow.log_params(params)
        logger.info(f"Logged {len(params)} hyperparameters")

    def log_model_with_validation(
            self, 
            model, 
            artifact_path: str, 
            X_sample: pd.DataFrame
        ):
        """
        Log a trained model with inferred signature and input examples.

        Supports sklearn, XGBoost, and LightGBM.

        Parameters
        ----------
        model : estimator
            Trained model instance.
        artifact_path : str
            Artifact path inside MLflow run.
        X_sample : pandas.DataFrame
            Sample dataset for inferring schema.

        Raises
        ------
        ValueError
            If the model type is not supported.
        """
        signature = infer_signature(X_sample, model.predict(X_sample))
        input_example = X_sample.iloc[:5]

        flavors = {
            "sklearn": (mlflow.sklearn.log_model, BaseEstimator, "sk_model"),
            "xgboost": (mlflow.xgboost.log_model, xgb.XGBModel, "xgb_model"),
            "lightgbm": (mlflow.lightgbm.log_model, lgb.LGBMModel, "lgb_model")
        }

        for flavor, (fn, cls, arg_name) in flavors.items():
            if isinstance(model, cls):
                return fn(**{arg_name: model},
                          artifact_path=artifact_path,
                          signature=signature,
                          input_example=input_example)
        raise ValueError(f"Unsupported model type: {type(model)}")
    
    def log_artifact(self, local_path: str, artifact_path: Optional[str] = None):
        """
        Log a local file as an MLflow artifact.

        Parameters
        ----------
        local_path : str
            Path to local file.
        artifact_path : str, optional
            Subdirectory in MLflow artifacts.
        """
        mlflow.log_artifact(local_path, artifact_path)
        logger.info(f"Logged artifact: {local_path} -> {artifact_path or '/'}")

    def log_table(self, data: pd.DataFrame, artifact_file: str):
        """
        Log a DataFrame as an MLflow artifact.

        Parameters
        ----------
        data : pandas.DataFrame
            Data to log.
        artifact_file : str
            File name to store inside MLflow run.
        """
        mlflow.log_table(data=data, artifact_file=artifact_file)
        logger.info(F"logged dataframe: {data} -> {artifact_file}")

    def load_model(self, model_uri: str):
        """
        Load a model from MLflow.

        Parameters
        ----------
        model_uri : str
            MLflow model URI.

        Returns
        -------
        mlflow.pyfunc.PyFuncModel
        """
        return mlflow.pyfunc.load_model(model_uri)

    def validate_model(
            self, 
            model_uri: str, 
            X_val: pd.DataFrame, 
            y_val: pd.Series, 
            metrics: Dict[str, Callable[[np.ndarray, np.ndarray], float]], 
            dataset_name: str = "validation"
        ):
        """
        Validate a model on a given dataset.

        Parameters
        ----------
        model_uri : str
            MLflow model URI.
        X_val : pandas.DataFrame
            Validation features.
        y_val : pandas.Series
            Validation labels.
        metrics : dict
            Metric name -> callable(y_true, y_pred).
        dataset_name : str, default="validation"
            Prefix for logged metrics.

        Returns
        -------
        dict
            Validation results {metric_name: score}.

        Raises
        ------
        Exception
            If model validation fails.
        """
        try:
            model = mlflow.pyfunc.load_model(model_uri)
            y_pred = model.predict(X_val)

            results = {}
            for name, fn in metrics.items():
                results[f"{dataset_name}_{name}"] = fn(y_val, y_pred)

            mlflow.log_metrics(results)
            mlflow.log_dict(
                {"validation_results": results},
                f"{dataset_name}_metrics.json"
            )
            return results
        
        except Exception as e:
            logger.error(f"Validation failed: {str(e)}")
            raise

    def register_model(self, model_uri: str, model_name: str):
        """
        Register a model in MLflow Model Registry.

        Parameters
        ----------
        model_uri : str
            Source model URI.
        model_name : str
            Name of registered model.
        
        Returns
        -------
        mlflow.entitites.Modelversion
            The registered model version.

        Raises
        ------
        MlflowException
            If model registration fails.
        """
        try:
            return mlflow.register_model(model_uri, model_name)
        except MlflowException as e:
            logger.error(f"Registration failed: {str(e)}")
            raise

    def transition_model_stage(
            self, 
            model_name: str, 
            version: int, 
            stage: str
        ):
        """
         Transition a registered model to a new stage.

        Parameters
        ----------
        model_name : str
            Registered model name.
        version : int
            Model version.
        stage : str
            Target stage, e.g., "Staging", "Production", "Archived".
        """
        self.client.transition_model_version_stage(
            name=model_name,
            version=version,
            stage=stage
        )

    def set_model_alias(
            self, 
            model_name: str, 
            alias: str, 
            version: int
        ):
        """
        Set an alias for a model version.

        Parameters
        ----------
        model_name : str
            Registered model name.
        alias : str
            Alias to assign.
        version : int
            Model version number.

        Raises
        ------
        MlflowException
            If alias setting fails.
        """
        try:
            self.client.set_registered_model_alias(
                name=model_name,
                alias=alias,
                version=version
            )
        except mlflow.exceptions.MlflowException as e:
            logger.error(f"Alias update failed: {str(e)}")
            raise

    def promote_model(
            self, 
            model_uri: str, 
            model_name: str, 
            validation_metrics: dict = None, 
            promotion_reason: str = "Periodic retraining", 
            user: str = "system",
            force: bool = False
        ):
        """
        Promote a model to Production with validation checks.

        Parameters
        ----------
        model_uri : str
            MLflow model URI.
        model_name : str
            Registered model name.
        validation_metrics : dict, optional
            Metrics to validate before promotion.
        promotion_reason : str, default="Periodic retraining"
            Reason for promotion.
        user : str, default="system"
            User promoting the model.
        force : bool, default=False
            If True, skip validation checks.

        Returns
        -------
        mlflow.entities.ModelVersion
            The promoted model version.
        
        Raises
        ------
        ValueError
            If validation metrics are required but not provided, or if
            validation checks fail.
        Exception
            If promotion workflow fails.
        """
        try:
            if not force and not validation_metrics:
                raise ValueError("Validation metics required when not forcing promotion")
            
            try:
                registered_model = self.client.get_registered_model(model_name)
            except mlflow.exceptions.MlflowException:
                registered_model = self.register_model(model_uri, model_name)
                logger.info(f"Registered new model: {model_name}")

            mv = self.client.create_model_version(
                name=model_name,
                source=model_uri,
                run_id=mlflow.active_run().info.run_id
            )

            if not force:
                self._validate_promotion(mv, validation_metrics)
            
            self._archive_existing_production(model_name)

            self.client.transition_model_version_stage(
                name=model_name,
                version=mv.version,
                stage="Production",
                archive_existing_versions=False
            )

            self.client.set_model_version_tag(
                name=model_name,
                version=mv.version,
                key="promotion_info",
                value=f"Promoted by {user} for {promotion_reason}"
            )
            
            logger.info(f"Successfully promoted {model_name} version {mv.version}")
            return mv
        
        except Exception as e:
            logger.error(f"Promotion failed: {str(e)}")
            self.client.set_model_version_tag(
                name=model_name,
                version=mv.version,
                key="promotion_status",
                value=f"failed: {str(e)}"
            )
            raise

    def _validate_promotion(self, model_version, validation_metrics):
        """
        Run validation checks before promotion.

        Parameters
        ----------
        model_version : mlflow.entities.model_registry.ModelVersion
            Model version to validate.
        validation_metrics : dict
            Dictionary {metric: (value, threshold)}.

        Raises
        ------
        ValueError
            If any validation checks fail.
        """
        failed_checks = []

        for metric_name, (value, threshold) in validation_metrics.items():
            if value > threshold:
                failed_checks.append(f"{metric_name} ({value} > {threshold})")

        if failed_checks:
            error_msg = f"Validation failed: {', '.join(failed_checks)}"
            self.client.set_model_version_tag(
                name=model_version.name,
                version=model_version.version,
                key="validation_errors",
                value=error_msg
            )
            raise ValueError(error_msg)
        
    def _archive_existing_production(self, model_name):
        """
        Archive all existing Production versions of a model.

        Parameters
        ----------
        model_name : str
            Registered model name.
        """
        prod_versions = self.client.get_latest_versions(model_name, stages=["Production"])

        for version in prod_versions:
            self.client.transition_model_version_stage(
                name=model_name,
                version=version.version,
                stage="Archived",
                archive_existing_versions=False
            )
            logger.info(f"Archived previous production version {version.version}")

    def deploy_model(self, model_name:str, stage: str = "Production"):
        """
        Build a Docker image for a model version.

        Parameters
        ----------
        model_name : str
            Registered model name.
        stage : str, default="Production"
            Stage to deploy from.
        """
        mlflow.models.build_docker(
            model_uri=f"models:/{model_name}/{stage}",
            name="stock-price-model"
        )

    def get_params(self, run_id: str):
        """
        Retrieve parameters from a run.

        Parameters
        ----------
        run_id : str
            Run identifier.

        Returns
        -------
        dict
            Run parameters.
        """
        try:
            run = self.client.get_run(run_id)
            parameters = run.data.params
        except mlflow.exceptions.MlflowException as e:
            print(f"Error: Run Id {run_id} not found. Details: {e}")
        return parameters

    def get_production_model(self, model_name: str) -> str:
        """
        Get URI of the current production model.

        Parameters
        ----------
        model_name : str
            Registered model name.

        Returns
        -------
        str
            Model URI in MLflow.
        """
        prod_versions = self.client.get_latest_versions(model_name, stages=["Production"])
        return f"models:/{model_name}/{prod_versions[0].version}"
    
    def get_latest_model_version(self, model_name:str, stage: Optional[str] = None) -> int:
        """
        Get latest model version.

        Parameters
        ----------
        model_name : str
            Registered model name.
        stage : str, optional
            Restrict search to a specific stage.

        Returns
        -------
        int
            Latest model version number.

        Raises
        ------
        ValueError
            If no versions are found for the model.
        """
        if stage:
            versions = self.client.get_latest_versions(model_name, stages=[stage])
        else:
            versions = self.client.get_latest_versions(model_name)

        if not versions:
            raise ValueError(f"No versions found for model {model_name}")
        
        return max(int(v.version) for v in versions)
    
    def compare_models(
            self, 
            model_uris: List[str], 
            X_test: pd.DataFrame, 
            y_test: pd.Series,
            metrics: Dict[str, Callable[[np.ndarray, np.ndarray], float]]
        ) -> Dict[str, Dict[str, float]]:
        """
        Compare multiple models on a test dataset.

        Parameters
        ----------
        model_uris : list of str
            List of MLflow model URIs.
        X_test : pandas.DataFrame
            Test features.
        y_test : pandas.Series
            Test labels.
        metrics : dict
            Metric name -> callable(y_true, y_pred).

        Returns
        -------
        dict
            Nested dictionary of results {model_uri: {metric: score}}.
        """
        results = {}

        for uri in model_uris:
            model = mlflow.pyfunc.load_model(uri)
            model_name = uri.split('/')[-2] if '/' in uri else uri
            y_pred = model.predict(X_test)

            model_results = {}
            for metric_name, metric_fn in metrics.items():
                model_results[metric_name] = metric_fn(y_test, y_pred)

            results[model_name] = model_results

        mlflow.log_dict(results, "model_comparison.json")
        logger.info(f"Compared {len(model_uris)} models")

        return results

    def drift_detector():
        pass

    def delete_run(self, run_id: str):
        """
        Delete a run by ID.

        Parameters
        ----------
        run_id : str
            Run identifier.
        """
        self.client.delete_run(run_id)
        logger.info(f"Deleted run: {run_id}")

    def delete_experiment(self, experiment_id: str):
        """
        Delete an experiment by ID.

        Parameters
        ----------
        experiment_id : str
            Experiment identifier.
        """
        self.client.delete_experiment(experiment_id)
        logger.info(f"Deleted Experiment: {experiment_id}")

    def delete_registered_model(self, model_name: str):
        """
        Delete a registered model.

        Parameters
        ----------
        model_name : str
            Registered model name.
        """
        self.client.delete_registered_model(model_name)
        logger.info(f"Deleted registered model: {model_name}")

    def delete_registered_models(self):
        """
        Delete all registered models in the registry.
        
        Warning
        -------
        This operation is irreversible and will delete all registered models
        and their versions. Use with caution.
        """
        for model in self.client.search_registered_models():
            self.client.delete_registered_model(model.name)
            logger.info(f"Deleted registered model: {model.name}")

    def search_runs(
            self, 
            filter_string: str = "", 
            max_results: int = 100, 
            order_by: Optional[List[str]] = None
        ) -> List[Dict[str, Any]]:
        """
        Search for runs in the current experiment.

        Parameters
        ----------
        filter_string : str, default=""
            MLflow filter query.
        max_results : int, default=100
            Max number of runs to return.
        order_by : list of str, optional
            Sort order for results.

        Returns
        -------
        list of dict
            List of run metadata records.

        Raises
        ------
        ValueError
            If the experiment is not found.
        """
        experiment = mlflow.get_experiment_by_name(self.experiment_name)
        if not experiment:
            raise ValueError(f"Experiment {self.experiment_name} not found")
        
        runs = mlflow.search_runs(
            experiment_ids=[experiment.experiment_id],
            filter_string=filter_string,
            max_results=max_results,
            order_by=order_by or ["metrics.val_score DESC"]
        )

        return runs.to_dict('records')

    def cleanup(self):
        """
        Perform cleanup operations for MLflow tracking.
        
        This method performs force cleanup of Windows file locks when using
        local file-based tracking. It's primarily useful for development
        and testing scenarios where file locks may persist.
        
        Warning
        -------
        This method uses Windows-specific commands and will only work on
        Windows systems. It forcefully removes tracking directories which
        may cause data loss if not used carefully.
        """
        try:
            if "file://" in self.tracking_uri:
                store_path = self.tracking_uri.split("file://")[1]
                os.system(f'rmdir /s /q "{store_path}"')
                logger.info("Performed Windows force cleanup")
        except Exception as e:
            logger.error(f"Windows cleanup failed: {str(e)}")