"""
Model Registry Module.

Provides a high-level interface to manage ML models using MLflow’s Model Registry.
This includes model registration, promotion, archiving, metadata tagging, and
retrieval of production models with caching.

Classes
-------
ModelStage : Enum
    Enumeration of ML model lifecycle stages.
ModelInfo : dataclass
    Container for storing model metadata and performance metrics.
ModelRegistry
    Manager for interacting with MLflow Model Registry, providing convenience
    methods for registration, promotion, and listing of models.
"""


import pandas as pd
import numpy as np
import logging 
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from dataclasses import dataclass
from datetime import datetime
from stock_price_predictor.utils.mlflow_utils import MLflowManager

logger = logging.getLogger(__name__)

class ModelStage(Enum):
    """
    Enumeration of valid model stages in the MLflow model registry.

    Attributes
    ----------
    STAGING : str
        Stage for models under validation and testing.
    PRODUCTION : str
        Stage for models serving live predictions.
    ARCHIVED : str
        Stage for deprecated or retired models.
    """
    STAGING ="Staging"
    PRODUCTION = "Production"
    ARCHIVED = "Archived"

@dataclass
class ModelInfo:
    """
    Data container for model metadata and registry information.
    
    This dataclass encapsulates all relevant information about a registered
    model including its identity, deployment stage, performance metrics,
    and source information.

    Attributes
    ----------
    name : str
        Model name.
    version : str
        Model version identifier.
    stage : str
        Model stage (Staging, Production, Archived).
    created_date : datetime
        Timestamp when the model was created.
    source_run_id : str
        MLflow run ID associated with this model.
    model_uri : str
        MLflow URI for accessing the model.
    performance_metrics : dict of str to float, optional
        Dictionary of performance metrics, if available.
    """
    name: str
    version: str
    stage: str
    created_date: datetime
    source_run_id: str
    model_uri: str
    performance_metrics: Optional[Dict[str, float]] = None

class ModelRegistry:
    """
    High-level interface for managing ML models in production environments.
    
    This class provides a comprehensive model registry system built on top of
    MLflow. It handles model registration, promotion workflows, caching, and
    metadata management. The registry supports the complete model lifecycle
    from development to production deployment.
    
    Attributes
    ----------
    mlflow_manager : MLflowManager
        Instance of MLflow manager for backend operations.
    project_name : str
        Project name for metadata and organization.
    _model_cache : dict
        Internal cache for loaded models and metadata.
    """

    def __init__(self, project_name: str = "stock-price-predictor"):
        """
        Initialize ModelRegistry with a project name.

        Parameters
        ----------
        project_name : str, default="stock-price-predictor"
            Name of the project for metadata tagging and organization.
        """
        self.mlflow_manager = MLflowManager()
        self.project_name = project_name
        self._model_cache = {}

        logger.info(f"Initialize ModelRegistry for project: {project_name}")

    def register_model(
            self, 
            model_name: str, 
            run_id: str, 
            description: Optional[str] = None, 
            tags: Optional[Dict[str, str]] = None,
            performance_metrics: Optional[Dict[str, float]] = None, 
            auto_promote: bool = False
        ) -> ModelInfo:
        """
        Register a model in MLflow Model Registry.

        Parameters
        ----------
        model_name : str
            Name of the model.
        run_id : str
            Run ID from which the model is logged.
        description : str, optional
            Description of the model version.
        tags : dict of str to str, optional
            Custom metadata tags.
        performance_metrics : dict of str to float, optional
            Performance metrics to attach as tags.
        auto_promote : bool, default=False
            If True, automatically promote the model to Production.

        Returns
        -------
        ModelInfo
            Metadata of the registered model.

        Raises
        ------
        Exception
            If registration fails.
        """
        try:
            logger.info(f"Registering model '{model_name}' from run {run_id}")
            
            with self.mlflow_manager.start_run():
                model_uri = f"runs:/{run_id}/model"
                registered_model = self.mlflow_manager.register_model(
                    model_uri=model_uri,
                    model_name=model_name
                )

                self._add_model_metadata(
                    model_name=model_name,
                    version=registered_model.version,
                    description=description,
                    tags=tags or {},
                    performance_metrics=performance_metrics or {},
                    source_run_id=run_id
                )

                if auto_promote:
                    self.promote_to_production(
                        model_name=model_name,
                        version=registered_model.version
                    )

                model_info = ModelInfo(
                    name=model_name,
                    version=registered_model.version,
                    stage="None" if not auto_promote else "Production",
                    created_date=datetime.now(),
                    source_run_id=run_id,
                    model_uri=model_uri,
                    performance_metrics=performance_metrics
                )
                
                self._update_cache(model_info=model_info)

                logger.info(f"Successfully registered {model_name} v{registered_model.version}")
                return model_info

        except Exception as e:
            logger.error(f"Failed to register model '{model_name}': {str(e)}")
            raise

    def get_production_model(self, model_name: str):
        """
        Retrieve the latest Production model.

        Uses caching to avoid repeated calls to MLflow.

        Parameters
        ----------
        model_name : str
            Name of the model.

        Returns
        -------
        object
            Loaded production model object.

        Raises
        ------
        Exception
            If model retrieval fails.
        """
        try:
            cache_key = f"{model_name}_production"
            if cache_key in self._model_cache:
                cached_model, cache_time = self._model_cache[cache_key]
                if (datetime.now() - cache_time).seconds < 3600:
                    return cached_model
                
            model_uri = f"models:/{model_name}/Production"
            model = self.mlflow_manager.load_model(model_uri)

            self._model_cache[cache_key] = (model, datetime.now())
            logger.info(f"Loaded production model: {model_name}")
            return model

        except Exception as e:
            logger.error(f"Failed to load production model '{model_name}': {str(e)}")
            raise

    def promote_to_production(
            self, 
            model_name: str, 
            version: Union[int, str], 
            archive_existing: bool = True
        ) -> bool:
        """
        Promote a model version to Production.

        Parameters
        ----------
        model_name : str
            Name of the model.
        version : int or str
            Version to promote.
        archive_existing : bool, default=True
            Whether to archive existing Production models.

        Returns
        -------
        bool
            True if promotion succeeds, False otherwise.

        Raises
        ------
        Exception
            If promotion fails.
        """
        try:
            logger.info(f"Promoting {model_name} v{version} to Production")
            if archive_existing:
                self._archive_production_models(model_name)
            
            self.mlflow_manager.transition_model_stage(
                model_name=model_name,
                version=int(version),
                stage="Production"
            )
            
            self._add_promotion_metadata(
                model_name=model_name,
                version=version
            )
            self._clear_cache(model_name)

            logger.info(f"Successfully promoted {model_name} v{version} to Production")
            return True
        
        except Exception as e:
            logger.error(f"Failed to promote {model_name} v{version}: {str(e)}")
            return False

    def get_model_info(self, model_name: str, stage: str = "Production") -> Optional[ModelInfo]:
        """
        Get metadata for a model at a specific stage.

        Parameters
        ----------
        model_name : str
            Name of the model.
        stage : str, default="Production"
            Model stage to query.

        Returns
        -------
        ModelInfo or None
            Model metadata, or None if not found.

        Raises
        ------
        Exception
            If retrieval fails.
        """
        try:
            versions = self.mlflow_manager.client.get_latest_versions(
                name=model_name,
                stages=[stage]
            )
            if not versions:
                return None
            
            version = versions[0]

            performance_metrics = {}
            for tag_key, tag_value in version.tags.items():
                if tag_key.startswith("metric_"):
                    metric_name = tag_key.replace("metric_", "")
                    try:
                        performance_metrics[metric_name] = float(tag_value)
                    except ValueError:
                        pass
            return ModelInfo(
                name=model_name,
                version=version.version,
                stage=version.current_stage,
                created_date=datetime.fromtimestamp(version.creation_timestamp / 1000),
                source_run_id=version.run_id,
                model_uri=f"models:/{model_name}/{stage}",
                performance_metrics=performance_metrics if performance_metrics else None
            )
                    
        except Exception as e:
            logger.error(f"Failed to get model info for '{model_name}': {str(e)}")
            return None
        
    def list_models(self, stage: Optional[str] = None) -> List[ModelInfo]:
        """
        List all registered models, optionally filtered by stage.

        Parameters
        ----------
        stage : str, optional
            Filter models by lifecycle stage.

        Returns
        -------
        list of ModelInfo
            List of registered models.

        Raises
        ------
        Exception
            If listing fails.
        """
        try:
            models = []
            registered_models = self.mlflow_manager.client.search_registered_models()

            for registered_model in registered_models:
                if stage:
                    versions = self.mlflow_manager.client.get_latest_versions(
                        registered_model.name,
                        stages=[stage]
                    )
                else:
                    versions = registered_model.latest_versions

            for version in versions:
                if not stage or version.current_stage == stage:
                    model_info = ModelInfo(
                        name=registered_model.name,
                        version=version.version,
                        stage=version.current_stage,
                        created_date=datetime.fromtimestamp(version.creation_timestamp / 1000),
                        source_run_id=version.run_id,
                        model_uri=f"models:/{registered_model.name}/{version.current_stage}"
                    )
                    models.append(model_info)

            return models

        except Exception as e:
            logger.error(f"Failed to list models: {str(e)}")
            return []
        
    def _add_model_metadata(
            self, 
            model_name: str, 
            version: int, 
            description: Optional[str], 
            tags: Dict[str, str], 
            performance_metrics: Dict[str, float], 
            source_run_id: str
        ):
        """
        Attach metadata and performance metrics to a model version.

        Parameters
        ----------
        model_name : str
            Model name.
        version : int
            Model version.
        description : str, optional
            Model description.
        tags : dict of str to str
            Custom tags.
        performance_metrics : dict of str to float
            Performance metrics to log as tags.
        source_run_id : str
            Source MLflow run ID.
        """
        standard_tags = {
            "project": self.project_name,
            "registered_date": datetime.now().isoformat(),
            "source_run_id": source_run_id,
            "registry_version": "1.0"
        }
        
        metric_tags = {f"metric_{k}": str(v) for k, v in performance_metrics.items()}

        all_tags = {**standard_tags, **tags, **metric_tags}

        for key, value in all_tags.items():
            self.mlflow_manager.client.set_model_version_tag(
                name=model_name,
                version=version,
                key=key,
                value=str(value)
            )

        if description:
            self.mlflow_manager.client.update_model_version(
                name=model_name,
                version=version,
                description=description
            )

    def _add_promotion_metadata(self, model_name: str, version: Union[int, str]):
        """
        Attach promotion metadata tags to a model version.

        Parameters
        ----------
        model_name : str
            Model name.
        version : int or str
            Model version.
        """
        promotion_tags = {
            "promoted_to_production": datetime.now().isoformat(),
            "promotion_method": "model_registry",
            "promoted_by": "system"
        }

        for key, value in promotion_tags.items():
            self.mlflow_manager.client.set_model_version_tag(
                name=model_name,
                version=int(version),
                key=key,
                value=value
            )

    def _archive_production_models(self, model_name:str):
        """
        Archive all existing Production models for a given model name.

        Parameters
        ----------
        model_name : str
            Model name.

        Raises
        ------
        Exception
            If archiving fails.
        """
        try:
            prod_versions = self.mlflow_manager.client.get_latest_versions(
                model_name,
                stages=["Production"]
            )
            
            for version in prod_versions:
                self.mlflow_manager.transition_model_stage(
                    model_name=model_name,
                    version=int(version.version),
                    stage="Archived"
                )
                logger.info(f"Archived {model_name} v{version.version}")

        except Exception as e:
            logger.warning(f"Failed to archive existing models: {str(e)}")

    def _update_cache(self, model_info: ModelInfo):
        """
        Update internal cache with model info.

        Parameters
        ----------
        model_info : ModelInfo
            Metadata of the model to cache.
        """
        cache_key = f"{model_info.name}_{model_info.stage.lower()}"
        self._model_cache[cache_key] = (model_info, datetime.now())

    def _clear_cache(self, model_name: Optional[str] = None):
        """
        Clear cache entries for a given model, or all models if None.

        Parameters
        ----------
        model_name : str, optional
            Model name to clear from cache. If None, clears all entries.
        """
        if model_name:
            keys_to_remove = [k for k in self._model_cache.keys() if model_name in k]
            for key in keys_to_remove:
                del self._model_cache[key]
        else:
            self._model_cache.clear()