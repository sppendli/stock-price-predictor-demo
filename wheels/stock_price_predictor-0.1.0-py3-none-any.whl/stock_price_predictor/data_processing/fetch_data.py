import yfinance as yf
import pandas as pd
from pathlib import Path
from datetime import date, datetime, timedelta
import logging
from typing import Union, Optional
from stock_price_predictor.utils.logger import configure_logger

def fetch_stock_data(
        tickers: Union[list[str], str],
        start_date: Union[str, date, datetime],
        end_date: Union[str, date, datetime],
        interval: str = '1d'
    ) -> pd.DataFrame:
    """
    Fetch historical stock price data from Yahoo Finance.

    Parameters
    ----------
    tickers : list[str] or str
        List of stock ticker symbols(e.g., ['AAPL', 'MSFT']) or a single ticker symbol.
    start_date : str or datetime
        Start date for fetching data (format: 'YYYY-MM-DD' or datetime object).
    end_date : str or datetime
        End date for fetching data (format: 'YYYY-MM-DD' or datetime object).
    interval : str, optional, default='1d'
        Data interval. Options include '1m', '5m', '15m', '1h', '1d', '1wk', '1mo'.

    Returns
    -------
    pandas.DataFrame
        Raw stock data with multi-level columns (e.g., ('Open', 'AAPL')).
    """
    df = yf.download(tickers, start=start_date, end=end_date, interval=interval)
    return df

def transform_yf_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transform raw Yahoo Finance data into a normalized tabular format.

    This function reshapes the multi-level column DataFrame into a flat format
    with columns: Date, Ticker, Open, High, Low, Close, Adj Close, Volume.

    Parameters
    ----------
    df : pandas.DataFrame
        Raw DataFrame returned by `yfinance.download()` with multi-level columns.

    Returns
    -------
    pandas.DataFrame
        Transformed DataFrame sorted by ticker and date, with each row representing
        a ticker's price data on a given date.
    """
    df.columns = df.columns.map(lambda x: (x[1], x[0]))
    df = df.stack(level=0).reset_index()
    df = df.rename(columns={"Price":"Ticker"})
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values(by=["Ticker", "Date"])
    return df

def save_raw_data(
        df: pd.DataFrame,
        output_dir: Optional[str] ="data/raw",
        filename: Optional[str] = None
    ) -> str:
    """
    Save DataFrame as a CSV file in the specified directory.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame to save.
    output_dir : str, optional, default="data/raw"
        Directory path where the file will be saved.
    filename : str, optional
        Custom filename. If not provided, a timestamped filename will be generated.

    Returns
    -------
    str
        Full path to the saved CSV file.

    Raises
    ------
    Exception
        If saving the file fails due to I/O or other issues.
    """
    try:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"stock_data_{timestamp}.csv"
        full_path = f"{output_dir}/{filename}"
        df.to_csv(full_path, index=False)

        logging.info(f"Data successfully saved to: {full_path}")
        return full_path
    
    except Exception as e:
        logging.error(f"Failed to save data: {str(e)}")
        raise


if __name__ == "__main__":
    data = fetch_stock_data(
        tickers = ['AAPL','MSFT','GOOG','LULU','WMT','AMZN','META','NFLX','GE','TGT','SPOT','NVDA','MCD','GME','BRK-B','TSLA'],
        start_date="2019-01-01",
        end_date=str(date.today())
    )
    data = transform_yf_data(data)
    save_raw_data(data)